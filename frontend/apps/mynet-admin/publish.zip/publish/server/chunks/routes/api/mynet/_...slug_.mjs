import { d as defineEventHandler, g as getMethod, a as getQuery, b as getCookie, r as readBody, c as createError, e as deleteCookie, s as setCookie } from '../../../nitro/nitro.mjs';
import 'unhead/server';
import 'vue';
import 'unhead/legacy';
import 'unhead/plugins';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'node:url';

const isoAgo = (minutesAgo) => new Date(Date.now() - minutesAgo * 6e4).toISOString();
const isoAhead = (daysAhead) => new Date(Date.now() + daysAhead * 864e5).toISOString();
let seqCounter = 900;
function nextMockId(prefix) {
  seqCounter += 1;
  return `${prefix}-${seqCounter}`;
}
function generateVoucherCode(planCode, n) {
  const clean = planCode.replace(/[^A-Z0-9]/g, "").slice(0, 4).padEnd(4, "X");
  const rand = ((n * 7919 + 104729) % 9e5 + 1e5).toString();
  return `MYNT-${clean}-${rand.slice(0, 4)}`;
}
function createSeedDatabase() {
  const zones = [
    {
      id: "zone-kaneshie",
      zoneCode: "KANESHIE",
      name: "Kaneshie Market Hub",
      district: "Okaikoi South",
      region: "Greater Accra",
      status: "LIVE",
      backhaulProvider: "MTN_FIBRE",
      backhaulCircuitRef: "MTN-BIZ-ACC-4401",
      upstreamDownMbps: 150,
      upstreamUpMbps: 75,
      upstreamMonthlyCost: 1500,
      upstreamIsCgnat: true,
      tunnelIp: "10.200.1.10",
      gpsLat: 5.5736,
      gpsLng: -0.2345,
      onlineDevices: 3,
      totalDevices: 3,
      activeSessions: 94,
      activeSubscribers: 168,
      currentDownMbps: 96.4,
      currentUpMbps: 28.2,
      monthlyRevenue: 14860,
      notes: "RB5009 gateway on Market Manager office wall; 2x mANTBox ax 15s dual-band sectors covering North & South stalls."
    },
    {
      id: "zone-mamprobi",
      zoneCode: "MAMPROBI",
      name: "Mamprobi Junction",
      district: "Ablekuma South",
      region: "Greater Accra",
      status: "LIVE",
      backhaulProvider: "TELECEL_FIBRE",
      backhaulCircuitRef: "TLC-FBR-ACC-1189",
      upstreamDownMbps: 100,
      upstreamUpMbps: 50,
      upstreamMonthlyCost: 900,
      upstreamIsCgnat: true,
      tunnelIp: "10.200.1.20",
      gpsLat: 5.5567,
      gpsLng: -0.2412,
      onlineDevices: 1,
      totalDevices: 2,
      activeSessions: 41,
      activeSubscribers: 82,
      currentDownMbps: 44.8,
      currentUpMbps: 13.5,
      monthlyRevenue: 7420,
      notes: "Backhaul shared with cold store UPS; Sector AP #1 under PoE injector inspection."
    },
    {
      id: "zone-madina",
      zoneCode: "MADINA-ZNG",
      name: "Madina Zongo Junction",
      district: "La Nkwantanang Madina",
      region: "Greater Accra",
      status: "LIVE",
      backhaulProvider: "TELECEL_FIBRE",
      backhaulCircuitRef: "TLC-FBR-MDN-2094",
      upstreamDownMbps: 200,
      upstreamUpMbps: 100,
      upstreamMonthlyCost: 1850,
      upstreamIsCgnat: true,
      tunnelIp: "10.200.1.40",
      gpsLat: 5.6782,
      gpsLng: -0.1669,
      onlineDevices: 2,
      totalDevices: 2,
      activeSessions: 112,
      activeSubscribers: 145,
      currentDownMbps: 132,
      currentUpMbps: 41.6,
      monthlyRevenue: 16940,
      notes: "High-density student & commercial corridor; 200 Mbps Telecel fibre with solar LiFePO4 backup."
    },
    {
      id: "zone-teshie",
      zoneCode: "TESHIE",
      name: "Teshie Nungua Estates",
      district: "Ledzokuku",
      region: "Greater Accra",
      status: "BUILD",
      backhaulProvider: "MTN_FIBRE",
      backhaulCircuitRef: "MTN-BIZ-TSH-0872",
      upstreamDownMbps: 100,
      upstreamUpMbps: 50,
      upstreamMonthlyCost: 800,
      upstreamIsCgnat: true,
      tunnelIp: "10.200.1.30",
      gpsLat: 5.5763,
      gpsLng: -0.1034,
      onlineDevices: 0,
      totalDevices: 1,
      activeSessions: 0,
      activeSubscribers: 0,
      currentDownMbps: 0,
      currentUpMbps: 0,
      monthlyRevenue: 0,
      notes: "12m mast erected; awaiting sector downtilt alignment & WireGuard handshake."
    }
  ];
  const plans = [
    {
      id: "plan-hour-1",
      planCode: "HOUR-1",
      name: "MyNet Express 1-Hour",
      planType: "TIME",
      durationMinutes: 60,
      dataCapMb: 1536,
      fairUseCapMb: 0,
      downKbps: 1e4,
      upKbps: 5e3,
      throttleDownKbps: 0,
      throttleUpKbps: 0,
      burstDownKbps: 15e3,
      burstUpKbps: 8e3,
      deviceLimit: 1,
      price: 3,
      wholesalePrice: 2.55,
      agentCommission: 0.45,
      taxInclusive: true,
      validityDays: 1,
      isPublic: true,
      isActive: true,
      sortOrder: 1,
      zoneIds: ["zone-kaneshie", "zone-mamprobi", "zone-madina"],
      activeSubscriptions: 58,
      vouchersAvailable: 28
    },
    {
      id: "plan-day-1",
      planCode: "DAY-1",
      name: "MyNet Daily Unlimited Pass",
      planType: "HYBRID",
      durationMinutes: 1440,
      dataCapMb: 5120,
      fairUseCapMb: 5120,
      downKbps: 15e3,
      upKbps: 8e3,
      throttleDownKbps: 3e3,
      throttleUpKbps: 1500,
      burstDownKbps: 2e4,
      burstUpKbps: 1e4,
      deviceLimit: 1,
      price: 8,
      wholesalePrice: 6.8,
      agentCommission: 1.2,
      taxInclusive: true,
      validityDays: 1,
      isPublic: true,
      isActive: true,
      sortOrder: 2,
      zoneIds: ["zone-kaneshie", "zone-mamprobi", "zone-madina"],
      activeSubscriptions: 124,
      vouchersAvailable: 42
    },
    {
      id: "plan-day-3",
      planCode: "DAY-3",
      name: "MyNet 3-Day Duo Pass",
      planType: "VOLUME",
      durationMinutes: 4320,
      dataCapMb: 15360,
      fairUseCapMb: 0,
      downKbps: 2e4,
      upKbps: 1e4,
      throttleDownKbps: 0,
      throttleUpKbps: 0,
      burstDownKbps: 25e3,
      burstUpKbps: 12e3,
      deviceLimit: 2,
      price: 20,
      wholesalePrice: 17.5,
      agentCommission: 2.5,
      taxInclusive: true,
      validityDays: 3,
      isPublic: true,
      isActive: true,
      sortOrder: 3,
      zoneIds: ["zone-kaneshie", "zone-mamprobi", "zone-madina"],
      activeSubscriptions: 69,
      vouchersAvailable: 19
    },
    {
      id: "plan-week-1",
      planCode: "WEEK-1",
      name: "MyNet Weekly Heavy 40 GB",
      planType: "VOLUME",
      durationMinutes: 10080,
      dataCapMb: 40960,
      fairUseCapMb: 0,
      downKbps: 25e3,
      upKbps: 12e3,
      throttleDownKbps: 0,
      throttleUpKbps: 0,
      burstDownKbps: 3e4,
      burstUpKbps: 15e3,
      deviceLimit: 2,
      price: 40,
      wholesalePrice: 35,
      agentCommission: 5,
      taxInclusive: true,
      validityDays: 7,
      isPublic: true,
      isActive: true,
      sortOrder: 4,
      zoneIds: ["zone-kaneshie", "zone-mamprobi", "zone-madina"],
      activeSubscriptions: 81,
      vouchersAvailable: 16
    },
    {
      id: "plan-month-1",
      planCode: "MONTH-1",
      name: "MyNet Home & Shop Monthly",
      planType: "UNLIMITED",
      durationMinutes: 43200,
      dataCapMb: 0,
      fairUseCapMb: 256e3,
      downKbps: 35e3,
      upKbps: 18e3,
      throttleDownKbps: 8e3,
      throttleUpKbps: 4e3,
      burstDownKbps: 45e3,
      burstUpKbps: 22e3,
      deviceLimit: 5,
      price: 120,
      wholesalePrice: 105,
      agentCommission: 15,
      taxInclusive: true,
      validityDays: 30,
      isPublic: true,
      isActive: true,
      sortOrder: 5,
      zoneIds: ["zone-kaneshie", "zone-mamprobi", "zone-madina"],
      activeSubscriptions: 63,
      vouchersAvailable: 8
    }
  ];
  const devices = [
    {
      id: "dev-gw-kaneshie",
      zoneId: "zone-kaneshie",
      zoneName: "Kaneshie Market Hub",
      zoneCode: "KANESHIE",
      name: "Kaneshie GW1",
      role: "GATEWAY",
      vendor: "MikroTik",
      model: "RB5009UG+S+IN",
      serialNumber: "MYN-24091-GW-001",
      macAddress: "48:8F:5A:24:00:01",
      routerosVersion: "7.16.2",
      managementIp: "192.168.88.1",
      tunnelIp: "10.200.1.10",
      restScheme: "http",
      restPort: 80,
      apiUsername: "magma-api",
      enrolmentStatus: "ENROLLED",
      status: "ONLINE",
      lastSeenAt: isoAgo(1),
      uptimeSeconds: 864e3,
      cpuLoad: 18,
      freeMemoryMb: 780,
      activeClients: 94,
      poeMode: "DC 24V UPS",
      notes: "Primary NAS (3799 CoA active), Hotspot + PPPoE concentrator"
    },
    {
      id: "dev-ap-kaneshie-n",
      zoneId: "zone-kaneshie",
      zoneName: "Kaneshie Market Hub",
      zoneCode: "KANESHIE",
      name: "Kaneshie North Sector AP",
      role: "AP",
      vendor: "MikroTik",
      model: "mANTBox ax 15s",
      serialNumber: "MYN-24091-AP-001",
      macAddress: "48:8F:5A:24:00:02",
      routerosVersion: "7.16.2",
      managementIp: "192.168.89.11",
      tunnelIp: "10.200.1.11",
      restScheme: "http",
      restPort: 80,
      apiUsername: "magma-api",
      enrolmentStatus: "ENROLLED",
      status: "ONLINE",
      lastSeenAt: isoAgo(1),
      uptimeSeconds: 432e3,
      cpuLoad: 24,
      freeMemoryMb: 192,
      activeClients: 53,
      poeMode: "24V Passive PoE",
      notes: "120\xB0 Wi-Fi 6 sector aimed at textile & Yam market stalls"
    },
    {
      id: "dev-ap-kaneshie-s",
      zoneId: "zone-kaneshie",
      zoneName: "Kaneshie Market Hub",
      zoneCode: "KANESHIE",
      name: "Kaneshie South Sector AP",
      role: "AP",
      vendor: "MikroTik",
      model: "mANTBox ax 15s",
      serialNumber: "MYN-24091-AP-002",
      macAddress: "48:8F:5A:24:00:03",
      routerosVersion: "7.16.2",
      managementIp: "192.168.89.12",
      tunnelIp: "10.200.1.12",
      restScheme: "http",
      restPort: 80,
      apiUsername: "magma-api",
      enrolmentStatus: "ENROLLED",
      status: "ONLINE",
      lastSeenAt: isoAgo(1),
      uptimeSeconds: 401200,
      cpuLoad: 19,
      freeMemoryMb: 204,
      activeClients: 41,
      poeMode: "24V Passive PoE",
      notes: "120\xB0 Wi-Fi 6 sector covering lorry terminal & footbridge"
    },
    {
      id: "dev-gw-mamprobi",
      zoneId: "zone-mamprobi",
      zoneName: "Mamprobi Junction",
      zoneCode: "MAMPROBI",
      name: "Mamprobi GW1",
      role: "GATEWAY",
      vendor: "MikroTik",
      model: "RB5009UG+S+IN",
      serialNumber: "MYN-24091-GW-002",
      macAddress: "48:8F:5A:24:00:04",
      routerosVersion: "7.16.2",
      managementIp: "192.168.88.1",
      tunnelIp: "10.200.1.20",
      restScheme: "http",
      restPort: 80,
      apiUsername: "magma-api",
      enrolmentStatus: "ENROLLED",
      status: "ONLINE",
      lastSeenAt: isoAgo(1),
      uptimeSeconds: 312400,
      cpuLoad: 14,
      freeMemoryMb: 642,
      activeClients: 41,
      poeMode: "DC 24V UPS",
      notes: "WireGuard peer healthy; CoA UDP/3799 verified"
    },
    {
      id: "dev-ap-mamprobi-1",
      zoneId: "zone-mamprobi",
      zoneName: "Mamprobi Junction",
      zoneCode: "MAMPROBI",
      name: "Mamprobi East AP",
      role: "AP",
      vendor: "MikroTik",
      model: "mANTBox ax 15s",
      serialNumber: "MYN-24091-AP-003",
      macAddress: "48:8F:5A:24:00:05",
      routerosVersion: "7.16.2",
      managementIp: "192.168.89.21",
      tunnelIp: "10.200.1.21",
      restScheme: "http",
      restPort: 80,
      apiUsername: "magma-api",
      enrolmentStatus: "ENROLLED",
      status: "OFFLINE",
      lastSeenAt: isoAgo(185),
      uptimeSeconds: 0,
      cpuLoad: 0,
      freeMemoryMb: 0,
      activeClients: 0,
      poeMode: "24V Passive PoE",
      notes: "24V passive PoE injector suspect \u2014 technician dispatched on WO-1002"
    },
    {
      id: "dev-gw-madina",
      zoneId: "zone-madina",
      zoneName: "Madina Zongo Junction",
      zoneCode: "MADINA-ZNG",
      name: "Madina Core GW1",
      role: "GATEWAY",
      vendor: "MikroTik",
      model: "CCR2004-1G-12S+2XS",
      serialNumber: "MYN-24091-GW-004",
      macAddress: "48:8F:5A:24:00:07",
      routerosVersion: "7.16.2",
      managementIp: "192.168.88.1",
      tunnelIp: "10.200.1.40",
      restScheme: "http",
      restPort: 80,
      apiUsername: "magma-api",
      enrolmentStatus: "ENROLLED",
      status: "ONLINE",
      lastSeenAt: isoAgo(1),
      uptimeSeconds: 121e4,
      cpuLoad: 22,
      freeMemoryMb: 3180,
      activeClients: 112,
      poeMode: "Dual AC PSU + Solar",
      notes: "High-capacity aggregation router for Madina corridor"
    },
    {
      id: "dev-ap-madina-1",
      zoneId: "zone-madina",
      zoneName: "Madina Zongo Junction",
      zoneCode: "MADINA-ZNG",
      name: "Madina TroTro Rank AP",
      role: "AP",
      vendor: "MikroTik",
      model: "mANTBox ax 15s",
      serialNumber: "MYN-24091-AP-004",
      macAddress: "48:8F:5A:24:00:08",
      routerosVersion: "7.16.2",
      managementIp: "192.168.89.41",
      tunnelIp: "10.200.1.41",
      restScheme: "http",
      restPort: 80,
      apiUsername: "magma-api",
      enrolmentStatus: "ENROLLED",
      status: "ONLINE",
      lastSeenAt: isoAgo(1),
      uptimeSeconds: 615e3,
      cpuLoad: 31,
      freeMemoryMb: 178,
      activeClients: 68,
      poeMode: "24V Passive PoE",
      notes: "Main commercial sector, band-steering active"
    },
    {
      id: "dev-gw-teshie",
      zoneId: "zone-teshie",
      zoneName: "Teshie Nungua Estates",
      zoneCode: "TESHIE",
      name: "Teshie Bench GW1",
      role: "GATEWAY",
      vendor: "MikroTik",
      model: "RB5009UG+S+IN",
      serialNumber: "MYN-24091-GW-003",
      macAddress: "48:8F:5A:24:00:06",
      routerosVersion: "7.16.1",
      managementIp: "192.168.88.1",
      tunnelIp: "10.200.1.30",
      restScheme: "http",
      restPort: 80,
      apiUsername: "magma-api",
      enrolmentStatus: "PENDING",
      status: "UNKNOWN",
      lastSeenAt: null,
      uptimeSeconds: 0,
      cpuLoad: 0,
      freeMemoryMb: 0,
      activeClients: 0,
      poeMode: "24V Bench",
      notes: "Pre-staged config ready; awaiting fibre ONT splice"
    }
  ];
  const subscribers = [
    {
      id: "sub-1",
      msisdn: "0244123456",
      fullName: "Ama Mensah",
      email: "ama.mensah@example.com",
      ghanaCardMasked: "GHA-*****01-0",
      subscriberType: "WALK_IN",
      authType: "HOTSPOT",
      homeZoneId: "zone-kaneshie",
      homeZoneName: "Kaneshie Market Hub",
      serviceAddress: "Kaneshie Market, Stall 41 (Fabric Lane)",
      status: "ACTIVE",
      kycStatus: "VERIFIED",
      activePlanCode: "DAY-1",
      activePlanName: "MyNet Daily Unlimited Pass",
      subscriptionId: "subs-1",
      subscriptionStatus: "ACTIVE",
      usedMb: 1840,
      purchasedMb: 5120,
      expiresAt: isoAhead(1),
      onlineNow: true,
      deviceCount: 1,
      lifetimeSpend: 284,
      lastSeenAt: isoAgo(2),
      createdAt: isoAgo(60 * 24 * 45)
    },
    {
      id: "sub-2",
      msisdn: "0201234567",
      fullName: "Kofi Boateng",
      email: "kofi.boateng@example.com",
      ghanaCardMasked: "GHA-*****02-0",
      subscriberType: "WALK_IN",
      authType: "HOTSPOT",
      homeZoneId: "zone-kaneshie",
      homeZoneName: "Kaneshie Market Hub",
      serviceAddress: "Kaneshie Lorry Station, Kiosk 14",
      status: "ACTIVE",
      kycStatus: "VERIFIED",
      activePlanCode: "DAY-3",
      activePlanName: "MyNet 3-Day Duo Pass",
      subscriptionId: "subs-2",
      subscriptionStatus: "ACTIVE",
      usedMb: 6420,
      purchasedMb: 15360,
      expiresAt: isoAhead(2),
      onlineNow: true,
      deviceCount: 2,
      lifetimeSpend: 410,
      lastSeenAt: isoAgo(1),
      createdAt: isoAgo(60 * 24 * 38)
    },
    {
      id: "sub-3",
      msisdn: "0551234567",
      fullName: "Akosua Owusu",
      email: "akosua.owusu@example.com",
      ghanaCardMasked: "GHA-*****03-0",
      subscriberType: "RESIDENTIAL",
      authType: "PPPOE",
      pppoeUsername: "mg-pppoe-03",
      homeZoneId: "zone-kaneshie",
      homeZoneName: "Kaneshie Market Hub",
      serviceAddress: "Bubiiashie First Stop, Hse 18B",
      status: "ACTIVE",
      kycStatus: "VERIFIED",
      activePlanCode: "MONTH-1",
      activePlanName: "MyNet Home & Shop Monthly",
      subscriptionId: "subs-3",
      subscriptionStatus: "ACTIVE",
      usedMb: 84200,
      purchasedMb: 256e3,
      expiresAt: isoAhead(19),
      onlineNow: true,
      deviceCount: 4,
      lifetimeSpend: 720,
      lastSeenAt: isoAgo(1),
      createdAt: isoAgo(60 * 24 * 120)
    },
    {
      id: "sub-4",
      msisdn: "0271234567",
      fullName: "Yaw Owusu Pharmacy",
      email: "yaw.pharmacy@example.com",
      ghanaCardMasked: "GHA-*****04-0",
      subscriberType: "BUSINESS",
      authType: "PPPOE",
      pppoeUsername: "mg-pppoe-04",
      homeZoneId: "zone-madina",
      homeZoneName: "Madina Zongo Junction",
      serviceAddress: "Madina Zongo Junction, Opposite Melcom",
      status: "ACTIVE",
      kycStatus: "VERIFIED",
      activePlanCode: "MONTH-1",
      activePlanName: "MyNet Home & Shop Monthly",
      subscriptionId: "subs-4",
      subscriptionStatus: "ACTIVE",
      usedMb: 128500,
      purchasedMb: 256e3,
      expiresAt: isoAhead(14),
      onlineNow: true,
      deviceCount: 5,
      lifetimeSpend: 1080,
      lastSeenAt: isoAgo(1),
      createdAt: isoAgo(60 * 24 * 150)
    },
    {
      id: "sub-5",
      msisdn: "0244555666",
      fullName: "Abena Asante",
      email: "abena.asante@example.com",
      subscriberType: "WALK_IN",
      authType: "HOTSPOT",
      homeZoneId: "zone-kaneshie",
      homeZoneName: "Kaneshie Market Hub",
      serviceAddress: "Kaneshie Market, Stall 45",
      status: "SUSPENDED",
      kycStatus: "NOT_REQUIRED",
      activePlanCode: "WEEK-1",
      activePlanName: "MyNet Weekly Heavy 40 GB",
      subscriptionId: "subs-5",
      subscriptionStatus: "SUSPENDED",
      usedMb: 19400,
      purchasedMb: 40960,
      expiresAt: isoAhead(3),
      onlineNow: false,
      deviceCount: 1,
      lifetimeSpend: 160,
      lastSeenAt: isoAgo(240),
      createdAt: isoAgo(60 * 24 * 28)
    },
    {
      id: "sub-6",
      msisdn: "0599111222",
      fullName: "Efua Mensah Coldstore",
      email: "efua.coldstore@example.com",
      ghanaCardMasked: "GHA-*****07-0",
      subscriberType: "BUSINESS",
      authType: "HOTSPOT",
      homeZoneId: "zone-mamprobi",
      homeZoneName: "Mamprobi Junction",
      serviceAddress: "Mamprobi Post Office Lane, Shop 4",
      status: "ACTIVE",
      kycStatus: "VERIFIED",
      activePlanCode: "MONTH-1",
      activePlanName: "MyNet Home & Shop Monthly",
      subscriptionId: "subs-6",
      subscriptionStatus: "ACTIVE",
      usedMb: 64100,
      purchasedMb: 256e3,
      expiresAt: isoAhead(22),
      onlineNow: true,
      deviceCount: 2,
      lifetimeSpend: 600,
      lastSeenAt: isoAgo(3),
      createdAt: isoAgo(60 * 24 * 90)
    },
    {
      id: "sub-7",
      msisdn: "0544332211",
      fullName: "Adjoa Safo",
      email: "adjoa.safo@example.com",
      subscriberType: "WALK_IN",
      authType: "HOTSPOT",
      homeZoneId: "zone-madina",
      homeZoneName: "Madina Zongo Junction",
      serviceAddress: "Madina Hostel Block C",
      status: "ACTIVE",
      kycStatus: "NOT_REQUIRED",
      activePlanCode: "WEEK-1",
      activePlanName: "MyNet Weekly Heavy 40 GB",
      subscriptionId: "subs-7",
      subscriptionStatus: "ACTIVE",
      usedMb: 28900,
      purchasedMb: 40960,
      expiresAt: isoAhead(5),
      onlineNow: true,
      deviceCount: 2,
      lifetimeSpend: 240,
      lastSeenAt: isoAgo(4),
      createdAt: isoAgo(60 * 24 * 35)
    },
    {
      id: "sub-8",
      msisdn: "0207776665",
      fullName: "Ibrahim Fuseini",
      email: "ibrahim.fuseini@example.com",
      ghanaCardMasked: "GHA-*****12-0",
      subscriberType: "RESIDENTIAL",
      authType: "PPPOE",
      pppoeUsername: "mg-pppoe-12",
      homeZoneId: "zone-mamprobi",
      homeZoneName: "Mamprobi Junction",
      serviceAddress: "Mamprobi Sempe, House 12",
      status: "SUSPENDED",
      kycStatus: "VERIFIED",
      activePlanCode: "MONTH-1",
      activePlanName: "MyNet Home & Shop Monthly",
      subscriptionId: "subs-8",
      subscriptionStatus: "SUSPENDED",
      usedMb: 112e3,
      purchasedMb: 256e3,
      expiresAt: isoAgo(60 * 24 * 2),
      onlineNow: false,
      deviceCount: 3,
      lifetimeSpend: 360,
      lastSeenAt: isoAgo(60 * 36),
      createdAt: isoAgo(60 * 24 * 95)
    }
  ];
  const clientDevices = [
    { id: "cdev-1", subscriberId: "sub-1", macAddress: "DC:A6:32:24:00:01", label: "Samsung Galaxy A25", firstSeenAt: isoAgo(60 * 24 * 45), lastSeenAt: isoAgo(2), isBlocked: false },
    { id: "cdev-2", subscriberId: "sub-2", macAddress: "DC:A6:32:24:00:02", label: "Tecno Spark 20", firstSeenAt: isoAgo(60 * 24 * 38), lastSeenAt: isoAgo(1), isBlocked: false },
    { id: "cdev-3", subscriberId: "sub-2", macAddress: "DC:A6:32:24:01:02", label: "HP ProBook Counter", firstSeenAt: isoAgo(60 * 24 * 20), lastSeenAt: isoAgo(12), isBlocked: false },
    { id: "cdev-4", subscriberId: "sub-3", macAddress: "48:8F:5A:99:10:03", label: "MikroTik LHG 5 CPE", firstSeenAt: isoAgo(60 * 24 * 120), lastSeenAt: isoAgo(1), isBlocked: false },
    { id: "cdev-5", subscriberId: "sub-4", macAddress: "48:8F:5A:99:10:04", label: "MikroTik LDF 5 CPE", firstSeenAt: isoAgo(60 * 24 * 150), lastSeenAt: isoAgo(1), isBlocked: false },
    { id: "cdev-6", subscriberId: "sub-5", macAddress: "DC:A6:32:24:00:05", label: "iPhone 13", firstSeenAt: isoAgo(60 * 24 * 28), lastSeenAt: isoAgo(240), isBlocked: true, blockedReason: "Unusual MAC spoofing alert" },
    { id: "cdev-7", subscriberId: "sub-6", macAddress: "DC:A6:32:24:00:06", label: "Shop POS Tablet", firstSeenAt: isoAgo(60 * 24 * 90), lastSeenAt: isoAgo(3), isBlocked: false }
  ];
  const sessions = [
    {
      id: "sess-live-1",
      subscriptionId: "subs-1",
      subscriberId: "sub-1",
      subscriberName: "Ama Mensah",
      msisdn: "0244123456",
      zoneId: "zone-kaneshie",
      zoneName: "Kaneshie Market Hub",
      deviceId: "dev-gw-kaneshie",
      deviceName: "Kaneshie GW1",
      acctSessionId: "rad-live-88201",
      nasIp: "10.200.1.10",
      framedIp: "10.10.1.74",
      macAddress: "DC:A6:32:24:00:01",
      startedAt: isoAgo(48),
      lastInterimAt: isoAgo(1),
      endedAt: null,
      inputOctets: 1489e5,
      outputOctets: 8924e5,
      sessionSeconds: 2880,
      terminateCause: null
    },
    {
      id: "sess-live-2",
      subscriptionId: "subs-2",
      subscriberId: "sub-2",
      subscriberName: "Kofi Boateng",
      msisdn: "0201234567",
      zoneId: "zone-kaneshie",
      zoneName: "Kaneshie Market Hub",
      deviceId: "dev-gw-kaneshie",
      deviceName: "Kaneshie GW1",
      acctSessionId: "rad-live-88204",
      nasIp: "10.200.1.10",
      framedIp: "10.10.1.91",
      macAddress: "DC:A6:32:24:00:02",
      startedAt: isoAgo(115),
      lastInterimAt: isoAgo(1),
      endedAt: null,
      inputOctets: 2104e5,
      outputOctets: 154e7,
      sessionSeconds: 6900,
      terminateCause: null
    },
    {
      id: "sess-live-3",
      subscriptionId: "subs-4",
      subscriberId: "sub-4",
      subscriberName: "Yaw Owusu Pharmacy",
      msisdn: "0271234567",
      zoneId: "zone-madina",
      zoneName: "Madina Zongo Junction",
      deviceId: "dev-gw-madina",
      deviceName: "Madina Core GW1",
      acctSessionId: "pppoe-live-4410",
      nasIp: "10.200.1.40",
      framedIp: "10.10.4.12",
      macAddress: "48:8F:5A:99:10:04",
      startedAt: isoAgo(1420),
      lastInterimAt: isoAgo(1),
      endedAt: null,
      inputOctets: 184e7,
      outputOctets: 962e7,
      sessionSeconds: 85200,
      terminateCause: null
    },
    {
      id: "sess-live-4",
      subscriptionId: "subs-6",
      subscriberId: "sub-6",
      subscriberName: "Efua Mensah Coldstore",
      msisdn: "0599111222",
      zoneId: "zone-mamprobi",
      zoneName: "Mamprobi Junction",
      deviceId: "dev-gw-mamprobi",
      deviceName: "Mamprobi GW1",
      acctSessionId: "rad-live-88219",
      nasIp: "10.200.1.20",
      framedIp: "10.10.2.68",
      macAddress: "DC:A6:32:24:00:06",
      startedAt: isoAgo(72),
      lastInterimAt: isoAgo(1),
      endedAt: null,
      inputOctets: 94e6,
      outputOctets: 512e6,
      sessionSeconds: 4320,
      terminateCause: null
    }
  ];
  const agents = [
    {
      id: "agent-1",
      agentCode: "MYN-AG-001",
      name: "Kwesi Mensah Ventures",
      msisdn: "0244555666",
      email: "kwesi.agent@mynet.gh",
      tier: "PREMIER",
      commissionRate: 0.15,
      territoryZoneId: "zone-kaneshie",
      territoryZoneName: "Kaneshie Market Hub",
      territoryZoneCode: "KANESHIE",
      walletAccountId: "TL-WAL-00192",
      floatBalance: 645.5,
      commissionEarnedMonth: 428,
      vouchersInStock: 18,
      vouchersSoldMonth: 196,
      status: "ACTIVE",
      kycStatus: "VERIFIED",
      createdAt: isoAgo(60 * 24 * 60)
    },
    {
      id: "agent-2",
      agentCode: "MYN-AG-002",
      name: "Adwoa Serwaa Enterprise",
      msisdn: "0201112223",
      email: "adwoa.agent@mynet.gh",
      tier: "SUPER",
      commissionRate: 0.18,
      territoryZoneId: "zone-madina",
      territoryZoneName: "Madina Zongo Junction",
      territoryZoneCode: "MADINA-ZNG",
      walletAccountId: "TL-WAL-00208",
      floatBalance: 1180,
      commissionEarnedMonth: 692.4,
      vouchersInStock: 24,
      vouchersSoldMonth: 312,
      status: "ACTIVE",
      kycStatus: "VERIFIED",
      createdAt: isoAgo(60 * 24 * 48)
    },
    {
      id: "agent-3",
      agentCode: "MYN-AG-003",
      name: "Issahaku Telecom Kiosk",
      msisdn: "0271112223",
      email: "issahaku.agent@mynet.gh",
      tier: "STANDARD",
      commissionRate: 0.12,
      territoryZoneId: "zone-mamprobi",
      territoryZoneName: "Mamprobi Junction",
      territoryZoneCode: "MAMPROBI",
      walletAccountId: "TL-WAL-00241",
      floatBalance: 92,
      commissionEarnedMonth: 134.5,
      vouchersInStock: 6,
      vouchersSoldMonth: 74,
      status: "ACTIVE",
      kycStatus: "VERIFIED",
      createdAt: isoAgo(60 * 24 * 25)
    }
  ];
  const voucherBatches = [
    {
      id: "batch-1",
      batchCode: "MYN-VB-001",
      planId: "plan-day-1",
      planCode: "DAY-1",
      planName: "MyNet Daily Unlimited Pass",
      zoneId: "zone-kaneshie",
      zoneName: "Kaneshie Market Hub",
      quantity: 12,
      availableCount: 3,
      assignedCount: 5,
      soldCount: 2,
      redeemedCount: 2,
      voidCount: 0,
      unitPrice: 8,
      wholesalePrice: 6.8,
      ownerType: "AGENT",
      ownerAgentId: "agent-1",
      ownerAgentName: "Kwesi Mensah Ventures",
      status: "ACTIVE",
      expiresAt: isoAhead(85),
      createdAt: isoAgo(60 * 24 * 12)
    },
    {
      id: "batch-2",
      batchCode: "MYN-VB-002",
      planId: "plan-hour-1",
      planCode: "HOUR-1",
      planName: "MyNet Express 1-Hour",
      zoneId: "zone-kaneshie",
      zoneName: "Kaneshie Market Hub",
      quantity: 10,
      availableCount: 0,
      assignedCount: 7,
      soldCount: 2,
      redeemedCount: 1,
      voidCount: 0,
      unitPrice: 3,
      wholesalePrice: 2.55,
      ownerType: "AGENT",
      ownerAgentId: "agent-1",
      ownerAgentName: "Kwesi Mensah Ventures",
      status: "ACTIVE",
      expiresAt: isoAhead(60),
      createdAt: isoAgo(60 * 24 * 9)
    },
    {
      id: "batch-3",
      batchCode: "MYN-VB-003",
      planId: "plan-week-1",
      planCode: "WEEK-1",
      planName: "MyNet Weekly Heavy 40 GB",
      zoneId: "zone-kaneshie",
      zoneName: "Kaneshie Market Hub",
      quantity: 8,
      availableCount: 2,
      assignedCount: 6,
      soldCount: 0,
      redeemedCount: 0,
      voidCount: 0,
      unitPrice: 40,
      wholesalePrice: 34,
      ownerType: "AGENT",
      ownerAgentId: "agent-1",
      ownerAgentName: "Kwesi Mensah Ventures",
      status: "ACTIVE",
      expiresAt: isoAhead(90),
      createdAt: isoAgo(60 * 24 * 5)
    },
    {
      id: "batch-4",
      batchCode: "MYN-VB-004",
      planId: "plan-day-3",
      planCode: "DAY-3",
      planName: "MyNet 3-Day Duo Pass",
      zoneId: "zone-madina",
      zoneName: "Madina Zongo Junction",
      quantity: 20,
      availableCount: 12,
      assignedCount: 8,
      soldCount: 0,
      redeemedCount: 0,
      voidCount: 0,
      unitPrice: 20,
      wholesalePrice: 17.5,
      ownerType: "BUSINESS",
      ownerAgentId: null,
      ownerAgentName: null,
      status: "ACTIVE",
      expiresAt: isoAhead(90),
      createdAt: isoAgo(60 * 24 * 3)
    }
  ];
  const vouchers = [];
  let vSerial = 1e3;
  const pushVouchers = (batch, allowanceLabel, zoneCode, statuses) => {
    statuses.forEach((st, idx) => {
      vSerial += 1;
      const isAgentOwned = st === "ASSIGNED" || st === "SOLD" || st === "REDEEMED";
      vouchers.push({
        id: `vch-${vSerial}`,
        batchId: batch.id,
        batchCode: batch.batchCode,
        planId: batch.planId,
        planCode: batch.planCode,
        planName: batch.planName,
        allowanceLabel,
        zoneId: batch.zoneId,
        zoneName: batch.zoneName,
        zoneCode,
        serial: `SN-${vSerial}`,
        code: generateVoucherCode(batch.planCode, vSerial),
        status: st,
        agentId: isAgentOwned ? batch.ownerAgentId || "agent-1" : null,
        agentName: isAgentOwned ? batch.ownerAgentName || "Kwesi Mensah Ventures" : null,
        price: batch.unitPrice,
        wholesalePrice: batch.wholesalePrice,
        commission: Number((batch.unitPrice - batch.wholesalePrice).toFixed(2)),
        customerMsisdn: st === "SOLD" || st === "REDEEMED" ? `0244810${10 + idx}` : null,
        customerName: st === "SOLD" || st === "REDEEMED" ? idx % 2 === 0 ? "Market Customer" : "Walk-in Buyer" : null,
        soldAt: st === "SOLD" || st === "REDEEMED" ? isoAgo(90 + idx * 45) : null,
        redeemedAt: st === "REDEEMED" ? isoAgo(60 + idx * 30) : null,
        expiresAt: batch.expiresAt,
        createdAt: batch.createdAt
      });
    });
  };
  pushVouchers(voucherBatches[0], "24 hrs \xB7 5 GB FUP \xB7 15 Mbps", "KANESHIE", [
    "ASSIGNED",
    "ASSIGNED",
    "ASSIGNED",
    "ASSIGNED",
    "ASSIGNED",
    "AVAILABLE",
    "AVAILABLE",
    "AVAILABLE",
    "SOLD",
    "SOLD",
    "REDEEMED",
    "REDEEMED"
  ]);
  pushVouchers(voucherBatches[1], "60 mins \xB7 1.5 GB \xB7 10 Mbps", "KANESHIE", [
    "ASSIGNED",
    "ASSIGNED",
    "ASSIGNED",
    "ASSIGNED",
    "ASSIGNED",
    "ASSIGNED",
    "ASSIGNED",
    "SOLD",
    "SOLD",
    "REDEEMED"
  ]);
  pushVouchers(voucherBatches[2], "7 days \xB7 40 GB \xB7 25 Mbps", "KANESHIE", [
    "ASSIGNED",
    "ASSIGNED",
    "ASSIGNED",
    "ASSIGNED",
    "ASSIGNED",
    "ASSIGNED",
    "AVAILABLE",
    "AVAILABLE"
  ]);
  pushVouchers(voucherBatches[3], "3 days \xB7 15 GB \xB7 2 devices", "MADINA-ZNG", [
    "AVAILABLE",
    "AVAILABLE",
    "AVAILABLE",
    "AVAILABLE",
    "AVAILABLE",
    "AVAILABLE",
    "ASSIGNED",
    "ASSIGNED",
    "ASSIGNED",
    "ASSIGNED"
  ]);
  const agentLedger = [
    {
      id: "led-1",
      agentId: "agent-1",
      agentName: "Kwesi Mensah Ventures",
      entryType: "FLOAT_TOPUP",
      amount: 800,
      balanceAfter: 800,
      reference: "MYN-FLT-9011",
      description: "MTN MoMo float top-up (0244555666)",
      provider: "MOMO_MTN",
      status: "COMPLETED",
      createdAt: isoAgo(60 * 24 * 10)
    },
    {
      id: "led-2",
      agentId: "agent-1",
      agentName: "Kwesi Mensah Ventures",
      entryType: "STOCK_PURCHASE",
      amount: -204,
      balanceAfter: 596,
      reference: "MYN-STK-9024",
      description: "Wholesale stock purchase: 30 \xD7 DAY-1 passes",
      provider: "WALLET",
      status: "COMPLETED",
      createdAt: isoAgo(60 * 24 * 7)
    },
    {
      id: "led-3",
      agentId: "agent-1",
      agentName: "Kwesi Mensah Ventures",
      entryType: "EARNING",
      amount: 149.5,
      balanceAfter: 745.5,
      reference: "MYN-COM-9052",
      description: "Retail commissions credited on redeemed & direct PIN sales",
      provider: "WALLET",
      status: "COMPLETED",
      createdAt: isoAgo(60 * 24 * 2)
    },
    {
      id: "led-4",
      agentId: "agent-1",
      agentName: "Kwesi Mensah Ventures",
      entryType: "PAYOUT",
      amount: -100,
      balanceAfter: 645.5,
      reference: "MYN-SET-9088",
      description: "Commission settlement payout to MTN MoMo 0244555666",
      provider: "MOMO_MTN",
      status: "COMPLETED",
      createdAt: isoAgo(60 * 18)
    },
    {
      id: "led-5",
      agentId: "agent-2",
      agentName: "Adwoa Serwaa Enterprise",
      entryType: "FLOAT_TOPUP",
      amount: 1200,
      balanceAfter: 1180,
      reference: "MYN-FLT-9094",
      description: "Telecel Cash float wallet funding",
      provider: "MOMO_TELECEL",
      status: "COMPLETED",
      createdAt: isoAgo(60 * 30)
    }
  ];
  const makeTx = (id, subscriberName, msisdn, zoneId, zoneName, planCode, planName, amount, method, provider, purpose, status, minsAgo, agentId = null, agentName = null) => {
    const net = Number((amount / 1.2).toFixed(2));
    const tax = Number((amount - net).toFixed(2));
    return {
      id,
      subscriberName,
      payerMsisdn: msisdn,
      zoneId,
      zoneName,
      planCode,
      planName,
      purpose,
      amount,
      netAmount: net,
      taxAmount: tax,
      taxBreakdown: {
        vat: Number((net * 0.15).toFixed(2)),
        nhil: Number((net * 0.025).toFixed(2)),
        getFund: Number((net * 0.025).toFixed(2))
      },
      paymentMethod: method,
      provider,
      providerReference: `PRV-${id.toUpperCase()}-GH`,
      internalReference: `MYN-${id.toUpperCase()}`,
      status,
      agentId,
      agentName,
      initiatedAt: isoAgo(minsAgo),
      paidAt: status === "SUCCESS" ? isoAgo(Math.max(1, minsAgo - 1)) : null
    };
  };
  const transactions = [
    makeTx("tx-101", "Ama Mensah", "0244123456", "zone-kaneshie", "Kaneshie Market Hub", "DAY-1", "MyNet Daily Unlimited Pass", 8, "MOMO_MTN", "HUBTEL", "BUNDLE", "SUCCESS", 18),
    makeTx("tx-102", "Kofi Boateng", "0201234567", "zone-kaneshie", "Kaneshie Market Hub", "DAY-3", "MyNet 3-Day Duo Pass", 20, "MOMO_TELECEL", "HUBTEL", "BUNDLE", "SUCCESS", 52),
    makeTx("tx-103", "Market Walk-in", "024481010", "zone-kaneshie", "Kaneshie Market Hub", "DAY-1", "MyNet Daily Unlimited Pass", 8, "CASH_FLOAT", "WALLET", "VOUCHER", "SUCCESS", 84, "agent-1", "Kwesi Mensah Ventures"),
    makeTx("tx-104", "Yaw Owusu Pharmacy", "0271234567", "zone-madina", "Madina Zongo Junction", "MONTH-1", "MyNet Home & Shop Monthly", 120, "CARD", "PAYSTACK", "INVOICE", "SUCCESS", 195),
    makeTx("tx-105", "Adjoa Safo", "0544332211", "zone-madina", "Madina Zongo Junction", "WEEK-1", "MyNet Weekly Heavy 40 GB", 40, "MOMO_MTN", "HUBTEL", "BUNDLE", "SUCCESS", 260),
    makeTx("tx-106", "Selorm Agbeko", "0248889991", "zone-kaneshie", "Kaneshie Market Hub", "HOUR-1", "MyNet Express 1-Hour", 3, "MOMO_MTN", "HUBTEL", "BUNDLE", "PENDING", 9),
    makeTx("tx-107", "Nana Yaa", "0267778889", "zone-mamprobi", "Mamprobi Junction", "DAY-1", "MyNet Daily Unlimited Pass", 8, "MOMO_AIRTELTIGO", "HUBTEL", "BUNDLE", "FAILED", 310),
    makeTx("tx-108", "Student Hostel Buyer", "0558021190", "zone-madina", "Madina Zongo Junction", "DAY-3", "MyNet 3-Day Duo Pass", 20, "CASH_FLOAT", "WALLET", "VOUCHER", "SUCCESS", 400, "agent-2", "Adwoa Serwaa Enterprise")
  ];
  const invoices = [
    {
      id: "inv-1",
      subscriberId: "sub-3",
      subscriberName: "Akosua Owusu",
      msisdn: "0551234567",
      subscriptionId: "subs-3",
      planName: "MyNet Home & Shop Monthly",
      zoneName: "Kaneshie Market Hub",
      invoiceNumber: "INV-MYN-0041",
      periodStart: "2026-11-01",
      periodEnd: "2026-11-30",
      subtotal: 100,
      taxAmount: 20,
      total: 120,
      amountPaid: 120,
      status: "PAID",
      dueAt: isoAgo(60 * 24 * 9),
      issuedAt: isoAgo(60 * 24 * 15),
      paidAt: isoAgo(60 * 24 * 12)
    },
    {
      id: "inv-2",
      subscriberId: "sub-4",
      subscriberName: "Yaw Owusu Pharmacy",
      msisdn: "0271234567",
      subscriptionId: "subs-4",
      planName: "MyNet Home & Shop Monthly",
      zoneName: "Madina Zongo Junction",
      invoiceNumber: "INV-MYN-0042",
      periodStart: "2026-11-01",
      periodEnd: "2026-11-30",
      subtotal: 100,
      taxAmount: 20,
      total: 120,
      amountPaid: 120,
      status: "PAID",
      dueAt: isoAgo(60 * 24 * 9),
      issuedAt: isoAgo(60 * 24 * 15),
      paidAt: isoAgo(60 * 3)
    },
    {
      id: "inv-3",
      subscriberId: "sub-8",
      subscriberName: "Ibrahim Fuseini",
      msisdn: "0207776665",
      subscriptionId: "subs-8",
      planName: "MyNet Home & Shop Monthly",
      zoneName: "Mamprobi Junction",
      invoiceNumber: "INV-MYN-0043",
      periodStart: "2026-11-01",
      periodEnd: "2026-11-30",
      subtotal: 100,
      taxAmount: 20,
      total: 120,
      amountPaid: 0,
      status: "OVERDUE",
      dueAt: isoAgo(60 * 24 * 5),
      issuedAt: isoAgo(60 * 24 * 15),
      paidAt: null
    },
    {
      id: "inv-4",
      subscriberId: "sub-6",
      subscriberName: "Efua Mensah Coldstore",
      msisdn: "0599111222",
      subscriptionId: "subs-6",
      planName: "MyNet Home & Shop Monthly",
      zoneName: "Mamprobi Junction",
      invoiceNumber: "INV-MYN-0044",
      periodStart: "2026-11-15",
      periodEnd: "2026-12-14",
      subtotal: 100,
      taxAmount: 20,
      total: 120,
      amountPaid: 0,
      status: "ISSUED",
      dueAt: isoAhead(5),
      issuedAt: isoAgo(60 * 24),
      paidAt: null
    }
  ];
  const zoneCosts = [
    { id: "cost-1", zoneId: "zone-kaneshie", zoneName: "Kaneshie Market Hub", category: "BACKHAUL", vendor: "MTN Business Fibre", reference: "MTN-NOV-2026", amount: 1500, periodStart: "2026-11-01", periodEnd: "2026-11-30", notes: "150 Mbps dedicated business fibre" },
    { id: "cost-2", zoneId: "zone-kaneshie", zoneName: "Kaneshie Market Hub", category: "POWER", vendor: "ECG Prepaid", reference: "ECG-KNS-882", amount: 320, periodStart: "2026-11-01", periodEnd: "2026-11-30", notes: "Gateway & PoE rack meter top-up" },
    { id: "cost-3", zoneId: "zone-kaneshie", zoneName: "Kaneshie Market Hub", category: "RENT", vendor: "Kaneshie Market Assoc.", reference: "KMA-ROOF-11", amount: 600, periodStart: "2026-11-01", periodEnd: "2026-11-30", notes: "Mast & cabinet space lease" },
    { id: "cost-4", zoneId: "zone-mamprobi", zoneName: "Mamprobi Junction", category: "BACKHAUL", vendor: "Telecel Business", reference: "TLC-NOV-2026", amount: 900, periodStart: "2026-11-01", periodEnd: "2026-11-30", notes: "100 Mbps fibre circuit" },
    { id: "cost-5", zoneId: "zone-madina", zoneName: "Madina Zongo Junction", category: "BACKHAUL", vendor: "Telecel Business", reference: "TLC-MDN-11", amount: 1850, periodStart: "2026-11-01", periodEnd: "2026-11-30", notes: "200 Mbps symmetric business link" }
  ];
  const alerts = [
    {
      id: "alt-1",
      zoneId: "zone-mamprobi",
      zoneName: "Mamprobi Junction",
      deviceId: "dev-ap-mamprobi-1",
      deviceName: "Mamprobi East AP",
      alertType: "DEVICE_OFFLINE",
      severity: "CRITICAL",
      message: "Sector AP Mamprobi East AP (10.200.1.21) missed 6 consecutive WireGuard keepalives. Suspect 24V passive PoE injector.",
      acknowledgedBy: null,
      acknowledgedAt: null,
      resolvedAt: null,
      createdAt: isoAgo(180)
    },
    {
      id: "alt-2",
      zoneId: "zone-mamprobi",
      zoneName: "Mamprobi Junction",
      deviceId: null,
      deviceName: null,
      alertType: "AGENT_LOW_FLOAT",
      severity: "WARNING",
      message: "Agent Issahaku Telecom Kiosk (MYN-AG-003) float balance dropped below GH\u20B5 100 threshold (GH\u20B5 92.00 remaining).",
      acknowledgedBy: null,
      acknowledgedAt: null,
      resolvedAt: null,
      createdAt: isoAgo(95)
    },
    {
      id: "alt-3",
      zoneId: "zone-kaneshie",
      zoneName: "Kaneshie Market Hub",
      deviceId: "dev-gw-kaneshie",
      deviceName: "Kaneshie GW1",
      alertType: "HIGH_CONCURRENCY",
      severity: "INFO",
      message: "Kaneshie Market Hub crossed 90 concurrent hotspot sessions during midday trading peak; airtime fairness active.",
      acknowledgedBy: "Araba Ops",
      acknowledgedAt: isoAgo(40),
      resolvedAt: null,
      createdAt: isoAgo(65)
    },
    {
      id: "alt-4",
      zoneId: "zone-kaneshie",
      zoneName: "Kaneshie Market Hub",
      deviceId: null,
      deviceName: null,
      alertType: "OUTBOX_DEAD_LETTER",
      severity: "WARNING",
      message: "1 RADIUS_DEPROVISION event in outbox exceeded 8 retries (NAS timeout during maintenance window).",
      acknowledgedBy: null,
      acknowledgedAt: null,
      resolvedAt: null,
      createdAt: isoAgo(210)
    }
  ];
  const tickets = [
    {
      id: "tkt-1",
      ticketNumber: "TKT-2041",
      zoneId: "zone-kaneshie",
      zoneName: "Kaneshie Market Hub",
      subscriberId: "sub-1",
      subscriberName: "Ama Mensah",
      subscriberMsisdn: "0244123456",
      category: "CONNECTIVITY",
      priority: "HIGH",
      status: "OPEN",
      subject: "Second phone cannot join on Daily Pass",
      description: "Customer wants to connect both stall phone and personal phone simultaneously on DAY-1 plan.",
      assignedTo: "staff-support",
      assignedToName: "Esi Support",
      slaDueAt: isoAhead(1),
      resolvedAt: null,
      createdAt: isoAgo(140),
      updatedAt: isoAgo(45),
      messages: [
        { id: "tm-1", ticketId: "tkt-1", authorType: "CUSTOMER", authorName: "Ama Mensah", body: "My second phone says maximum simultaneous sessions reached.", createdAt: isoAgo(140) },
        { id: "tm-2", ticketId: "tkt-1", authorType: "STAFF", authorName: "Esi Support", body: "Checked RADIUS Simultaneous-Use:=1 on DAY-1. Advising upgrade to DAY-3 Duo Pass (2 devices).", createdAt: isoAgo(45) }
      ]
    },
    {
      id: "tkt-2",
      ticketNumber: "TKT-2042",
      zoneId: "zone-mamprobi",
      zoneName: "Mamprobi Junction",
      agentId: "agent-3",
      agentName: "Issahaku Telecom Kiosk",
      category: "DEVICE",
      priority: "URGENT",
      status: "IN_PROGRESS",
      subject: "Weak indoor signal on Mamprobi East lane",
      description: "Field agent reports customers near East lane seeing weak 2.4GHz signal since morning.",
      assignedTo: "staff-tech",
      assignedToName: "Yaw Technician",
      slaDueAt: isoAhead(0.25),
      resolvedAt: null,
      createdAt: isoAgo(175),
      updatedAt: isoAgo(30),
      messages: [
        { id: "tm-3", ticketId: "tkt-2", authorType: "AGENT", authorName: "Issahaku Telecom Kiosk", body: "Customers around Sempe East cannot see the MyNet SSID indoors.", createdAt: isoAgo(175) },
        { id: "tm-4", ticketId: "tkt-2", authorType: "STAFF", authorName: "Yaw Technician", body: "Confirmed Mamprobi East AP offline. En route with spare 24V passive PoE injector.", createdAt: isoAgo(30) }
      ]
    },
    {
      id: "tkt-3",
      ticketNumber: "TKT-2043",
      zoneId: "zone-kaneshie",
      zoneName: "Kaneshie Market Hub",
      agentId: "agent-1",
      agentName: "Kwesi Mensah Ventures",
      category: "VOUCHER",
      priority: "NORMAL",
      status: "RESOLVED",
      subject: "Re-send voucher SMS to customer 024481010",
      description: "Customer accidentally deleted SMS with voucher code before redeeming on captive portal.",
      assignedTo: "staff-support",
      assignedToName: "Esi Support",
      slaDueAt: isoAgo(60),
      resolvedAt: isoAgo(120),
      createdAt: isoAgo(300),
      updatedAt: isoAgo(120),
      messages: [
        { id: "tm-5", ticketId: "tkt-3", authorType: "AGENT", authorName: "Kwesi Mensah Ventures", body: "Please confirm SMS delivery for serial SN-1009.", createdAt: isoAgo(300) },
        { id: "tm-6", ticketId: "tkt-3", authorType: "STAFF", authorName: "Esi Support", body: "Resent via Hubtel SMS gateway; customer online now.", createdAt: isoAgo(120) }
      ]
    }
  ];
  const workOrders = [
    {
      id: "wo-1001",
      orderNumber: "WO-1001",
      zoneId: "zone-kaneshie",
      zoneName: "Kaneshie Market Hub",
      subscriberId: "sub-3",
      subscriberName: "Akosua Owusu",
      serviceAddress: "Bubiiashie First Stop, Hse 18B",
      orderType: "INSTALL",
      status: "SCHEDULED",
      assignedTo: "staff-tech",
      assignedToName: "Yaw Technician",
      scheduledAt: isoAhead(1),
      checklist: ["Mount LHG 5 CPE on roof pole", "Install surge arrestor + outdoor Cat6", "Provision PPPoE mg-pppoe-03 in radcheck"],
      materials: ["1x MikroTik LHG 5", "25m UV Cat6", "1x Surge Arrestor"],
      cost: 0,
      completedAt: null,
      createdAt: isoAgo(60 * 24 * 2)
    },
    {
      id: "wo-1002",
      orderNumber: "WO-1002",
      zoneId: "zone-mamprobi",
      zoneName: "Mamprobi Junction",
      subscriberId: null,
      subscriberName: null,
      serviceAddress: "Mamprobi Coldstore Mast \u2014 East Sector",
      orderType: "REPAIR",
      status: "EN_ROUTE",
      assignedTo: "staff-tech",
      assignedToName: "Yaw Technician",
      scheduledAt: isoAhead(0.1),
      checklist: ["Verify 24V passive PoE voltage (never 48V 802.3af)", "Swap gigabit passive PoE injector", "Confirm WireGuard handshake & CoA 3799"],
      materials: ["1x MikroTik 24V 1.2A PoE Injector"],
      cost: 150,
      completedAt: null,
      createdAt: isoAgo(160)
    },
    {
      id: "wo-1003",
      orderNumber: "WO-1003",
      zoneId: "zone-teshie",
      zoneName: "Teshie Nungua Estates",
      subscriberId: null,
      subscriberName: null,
      serviceAddress: "Teshie First Junction Mast",
      orderType: "SURVEY",
      status: "DONE",
      assignedTo: "staff-ops",
      assignedToName: "Araba Ops",
      scheduledAt: isoAgo(60 * 24 * 4),
      checklist: ["RF spectrum scan 2.4GHz (1/6/11) & 5GHz non-DFS", "Confirm mast earthing < 5 ohms", "Verify MTN fibre ONT termination"],
      materials: [],
      cost: 80,
      completedAt: isoAgo(60 * 24 * 3),
      createdAt: isoAgo(60 * 24 * 5)
    }
  ];
  const staff = [
    { id: "staff-admin", fullName: "Nana Kwame Admin", msisdn: "0244000001", email: "admin@mynet.gh", role: "ADMIN", zoneIds: ["zone-kaneshie", "zone-mamprobi", "zone-madina", "zone-teshie"], zoneNames: ["All Zones"], status: "ACTIVE", lastLoginAt: isoAgo(12), createdAt: isoAgo(60 * 24 * 120) },
    { id: "staff-ops", fullName: "Araba Network Ops", msisdn: "0244000002", email: "ops@mynet.gh", role: "OPS", zoneIds: ["zone-kaneshie", "zone-madina"], zoneNames: ["Kaneshie", "Madina"], status: "ACTIVE", lastLoginAt: isoAgo(48), createdAt: isoAgo(60 * 24 * 100) },
    { id: "staff-tech", fullName: "Yaw Field Engineer", msisdn: "0244777888", email: "yaw@mynet.gh", role: "TECHNICIAN", zoneIds: ["zone-kaneshie", "zone-mamprobi", "zone-teshie"], zoneNames: ["Kaneshie", "Mamprobi", "Teshie"], status: "ACTIVE", lastLoginAt: isoAgo(95), createdAt: isoAgo(60 * 24 * 80) },
    { id: "staff-support", fullName: "Esi Helpdesk Lead", msisdn: "0244000004", email: "esi@mynet.gh", role: "SUPPORT", zoneIds: ["zone-kaneshie", "zone-madina"], zoneNames: ["Kaneshie", "Madina"], status: "ACTIVE", lastLoginAt: isoAgo(25), createdAt: isoAgo(60 * 24 * 60) },
    { id: "staff-finance", fullName: "Kojo Revenue & Tax", msisdn: "0244000005", email: "finance@mynet.gh", role: "FINANCE", zoneIds: ["zone-kaneshie", "zone-mamprobi", "zone-madina"], zoneNames: ["All Live Zones"], status: "ACTIVE", lastLoginAt: isoAgo(180), createdAt: isoAgo(60 * 24 * 45) }
  ];
  const outbox = [
    { id: "obx-1", eventType: "RADIUS_PROVISION", aggregateId: "subs-1", summary: "radcheck + radreply sync for mg:subs-1 (15M/8M)", status: "DONE", attempts: 1, nextAttemptAt: isoAgo(18), createdAt: isoAgo(18), processedAt: isoAgo(18) },
    { id: "obx-2", eventType: "SMS_SEND", aggregateId: "subs-2", summary: "Hubtel receipt SMS to 0201234567 (MyNet 3-Day Duo Pass)", status: "PENDING", attempts: 1, nextAttemptAt: isoAhead(0.01), lastError: "Provider HTTP 429 \u2014 queued for retry", createdAt: isoAgo(7) },
    { id: "obx-3", eventType: "RADIUS_DEPROVISION", aggregateId: "subs-8", summary: "CoA Disconnect-Request UDP/3799 for overdue PPPoE mg-pppoe-12", status: "DEAD", attempts: 8, nextAttemptAt: isoAhead(0.5), lastError: "NAS 10.200.1.21 unreachable after 8 attempts", createdAt: isoAgo(210) },
    { id: "obx-4", eventType: "COA_RATE_LIMIT", aggregateId: "subs-4", summary: "Mikrotik-Rate-Limit update 35M/18M on Madina Core GW1", status: "DONE", attempts: 1, nextAttemptAt: isoAgo(190), createdAt: isoAgo(190), processedAt: isoAgo(190) }
  ];
  const auditLog = [
    { id: "aud-1", actorType: "STAFF", actorName: "Nana Kwame Admin", action: "DEVICE_CONFIG_PUSHED", entity: "magma_devices", entityId: "dev-gw-kaneshie", summary: "Pushed RouterOS v7 hotspot + walled-garden + CoA 3799 config to Kaneshie GW1", ipAddress: "10.200.0.1", createdAt: isoAgo(35) },
    { id: "aud-2", actorType: "AGENT", actorName: "Kwesi Mensah Ventures", action: "VOUCHER_SOLD", entity: "magma_vouchers", entityId: "vch-1009", summary: "Sold DAY-1 voucher SN-1009 (GH\u20B5 8.00) to 024481010", ipAddress: "102.176.84.19", createdAt: isoAgo(84) },
    { id: "aud-3", actorType: "STAFF", actorName: "Araba Network Ops", action: "SUBSCRIBER_SUSPENDED", entity: "magma_subscribers", entityId: "sub-5", summary: "Suspended Abena Asante (0244555666) & sent CoA disconnect", ipAddress: "10.200.0.4", createdAt: isoAgo(240) },
    { id: "aud-4", actorType: "STAFF", actorName: "Kojo Revenue & Tax", action: "AGENT_SETTLEMENT_PAID", entity: "magma_agent_ledger", entityId: "led-4", summary: "Settled GH\u20B5 100.00 commission payout to Kwesi Mensah Ventures via MTN MoMo", ipAddress: "10.200.0.8", createdAt: isoAgo(60 * 18) }
  ];
  const bandwidthSeries = [
    { hour: "06:00", kaneshieDown: 38, kaneshieUp: 11, mamprobiDown: 19, mamprobiUp: 6, sessions: 96 },
    { hour: "08:00", kaneshieDown: 64, kaneshieUp: 18, mamprobiDown: 28, mamprobiUp: 9, sessions: 152 },
    { hour: "10:00", kaneshieDown: 88, kaneshieUp: 24, mamprobiDown: 39, mamprobiUp: 12, sessions: 214 },
    { hour: "12:00", kaneshieDown: 108, kaneshieUp: 31, mamprobiDown: 46, mamprobiUp: 14, sessions: 268 },
    { hour: "14:00", kaneshieDown: 96, kaneshieUp: 28, mamprobiDown: 45, mamprobiUp: 14, sessions: 247 },
    { hour: "16:00", kaneshieDown: 112, kaneshieUp: 34, mamprobiDown: 51, mamprobiUp: 16, sessions: 289 },
    { hour: "18:00", kaneshieDown: 124, kaneshieUp: 39, mamprobiDown: 58, mamprobiUp: 19, sessions: 318 },
    { hour: "20:00", kaneshieDown: 102, kaneshieUp: 29, mamprobiDown: 54, mamprobiUp: 17, sessions: 276 }
  ];
  const revenueSeries = [
    { day: "Mon", momo: 1420, vouchers: 860, pppoe: 480 },
    { day: "Tue", momo: 1580, vouchers: 940, pppoe: 360 },
    { day: "Wed", momo: 1510, vouchers: 1020, pppoe: 600 },
    { day: "Thu", momo: 1790, vouchers: 1150, pppoe: 480 },
    { day: "Fri", momo: 2140, vouchers: 1380, pppoe: 720 },
    { day: "Sat", momo: 2460, vouchers: 1640, pppoe: 360 },
    { day: "Sun", momo: 1890, vouchers: 1190, pppoe: 240 }
  ];
  return {
    business: {
      id: "b8209d2c-7e41-4c9a-9f15-2b8a9d1e0001",
      name: "MyNet Broadband Ghana",
      clientId: "mynet_live_accra_01",
      clientSecretHint: "\u2022\u2022\u2022\u2022\u2022\u2022\u2022\u20227f2a"
    },
    zones,
    zoneCosts,
    plans,
    devices,
    subscribers,
    clientDevices,
    sessions,
    voucherBatches,
    vouchers,
    agents,
    agentLedger,
    transactions,
    invoices,
    alerts,
    tickets,
    workOrders,
    staff,
    outbox,
    auditLog,
    bandwidthSeries,
    revenueSeries
  };
}
const GLOBAL_KEY = "__MYNET_MOCK_DB__";
function getMockDb() {
  const g = globalThis;
  if (!g[GLOBAL_KEY]) {
    g[GLOBAL_KEY] = createSeedDatabase();
  }
  return g[GLOBAL_KEY];
}
function resetMockDb() {
  const g = globalThis;
  g[GLOBAL_KEY] = createSeedDatabase();
  return g[GLOBAL_KEY];
}
function recomputeBatchCounts(db, batchId) {
  const batch = db.voucherBatches.find((b) => b.id === batchId);
  if (!batch) return;
  const rows = db.vouchers.filter((v) => v.batchId === batchId);
  batch.quantity = rows.length;
  batch.availableCount = rows.filter((v) => v.status === "AVAILABLE").length;
  batch.assignedCount = rows.filter((v) => v.status === "ASSIGNED").length;
  batch.soldCount = rows.filter((v) => v.status === "SOLD").length;
  batch.redeemedCount = rows.filter((v) => v.status === "REDEEMED").length;
  batch.voidCount = rows.filter((v) => v.status === "VOID").length;
}
function recomputeAgentStock(db, agentId) {
  const agent = db.agents.find((a) => a.id === agentId);
  if (!agent) return;
  agent.vouchersInStock = db.vouchers.filter((v) => v.agentId === agentId && v.status === "ASSIGNED").length;
}

function ok(result, message = "OK") {
  return {
    success: true,
    message,
    result,
    error: null,
    targetUrl: ""
  };
}
function getActiveAgentId(event, fallbackId = "agent-1") {
  const cookieAgent = getCookie(event, "mynet_agent_id");
  const db = getMockDb();
  if (cookieAgent && db.agents.some((a) => a.id === cookieAgent)) return cookieAgent;
  return fallbackId;
}
const ____slug_ = defineEventHandler(async (event) => {
  var _a, _b, _c, _d, _e, _f, _g, _h, _i, _j, _k, _l;
  const method = getMethod(event).toUpperCase();
  const rawSlug = ((_a = event.context.params) == null ? void 0 : _a.slug) || "";
  const path = "/" + String(rawSlug).replace(/^\/+|\/+$/g, "");
  const query = getQuery(event);
  const db = getMockDb();
  if (path === "/demo/reset" && method === "POST") {
    resetMockDb();
    return ok({ reset: true }, "Demo data restored to clean baseline.");
  }
  if (path === "/auth/session" && method === "GET") {
    const portal = String(query.portal || "admin");
    if (portal === "agent") {
      const signedOut2 = getCookie(event, "mynet_agent_logged_out") === "1";
      if (signedOut2) {
        return ok(null);
      }
      const agentId = getActiveAgentId(event);
      const agent = db.agents.find((a) => a.id === agentId) || db.agents[0];
      return ok({
        authenticated: true,
        portal: "agent",
        id: agent.id,
        name: agent.name,
        role: `${agent.tier} Reseller`,
        msisdn: agent.msisdn,
        email: agent.email,
        code: agent.agentCode,
        territoryZoneId: agent.territoryZoneId,
        territoryZoneName: agent.territoryZoneName,
        tier: agent.tier,
        commissionRate: agent.commissionRate,
        tenantName: db.business.name,
        businessId: db.business.id
      });
    }
    const signedOut = getCookie(event, "mynet_admin_logged_out") === "1";
    if (signedOut) {
      return ok(null);
    }
    const staffId = getCookie(event, "mynet_admin_id") || "staff-admin";
    const member = db.staff.find((s) => s.id === staffId) || db.staff[0];
    return ok({
      authenticated: true,
      portal: "admin",
      id: member.id,
      name: member.fullName,
      role: member.role,
      msisdn: member.msisdn,
      email: member.email,
      zoneIds: member.zoneIds,
      tenantName: db.business.name,
      businessId: db.business.id
    });
  }
  if (path === "/auth/admin-login" && method === "POST") {
    const body = await readBody(event);
    let member = db.staff[0];
    if ((body == null ? void 0 : body.mode) === "apikey") {
      if (!body.clientId || !body.clientSecret) {
        throw createError({ statusCode: 400, statusMessage: "ClientId and ClientSecret are required." });
      }
    } else {
      const msisdn = String((body == null ? void 0 : body.msisdn) || "").trim();
      const pin = String((body == null ? void 0 : body.pin) || "").trim();
      if (!msisdn || pin.length < 4) {
        throw createError({ statusCode: 400, statusMessage: "Enter staff phone number and 4-digit PIN." });
      }
      const found = db.staff.find((s) => s.msisdn === msisdn || s.email.toLowerCase() === msisdn.toLowerCase());
      if (found) member = found;
    }
    member.lastLoginAt = (/* @__PURE__ */ new Date()).toISOString();
    deleteCookie(event, "mynet_admin_logged_out", { path: "/" });
    setCookie(event, "mynet_admin_id", member.id, { path: "/", httpOnly: false, maxAge: 86400 * 7 });
    return ok({
      authenticated: true,
      portal: "admin",
      id: member.id,
      name: member.fullName,
      role: member.role,
      msisdn: member.msisdn,
      email: member.email,
      zoneIds: member.zoneIds,
      tenantName: db.business.name,
      businessId: db.business.id
    }, "Signed in to MyNet Admin.");
  }
  if (path === "/auth/agent-login" && method === "POST") {
    const body = await readBody(event);
    const identifier = String((body == null ? void 0 : body.agentIdentifier) || "").trim();
    const pin = String((body == null ? void 0 : body.pin) || "").trim();
    if (!identifier || pin.length < 4) {
      throw createError({ statusCode: 400, statusMessage: "Enter your registered Agent phone/code and 4-digit PIN." });
    }
    const found = db.agents.find(
      (a) => a.msisdn === identifier || a.agentCode.toLowerCase() === identifier.toLowerCase() || a.email.toLowerCase() === identifier.toLowerCase()
    ) || db.agents[0];
    if (found.status === "SUSPENDED") {
      throw createError({ statusCode: 403, statusMessage: "This agent wallet is currently suspended. Contact MyNet Operations." });
    }
    deleteCookie(event, "mynet_agent_logged_out", { path: "/" });
    setCookie(event, "mynet_agent_id", found.id, { path: "/", httpOnly: false, maxAge: 86400 * 7 });
    return ok({
      authenticated: true,
      portal: "agent",
      id: found.id,
      name: found.name,
      role: `${found.tier} Reseller`,
      msisdn: found.msisdn,
      email: found.email,
      code: found.agentCode,
      territoryZoneId: found.territoryZoneId,
      territoryZoneName: found.territoryZoneName,
      tier: found.tier,
      commissionRate: found.commissionRate,
      tenantName: db.business.name,
      businessId: db.business.id
    }, "Welcome back to MyNet Agent.");
  }
  if (path === "/auth/logout" && method === "POST") {
    const body = await readBody(event).catch(() => ({}));
    if ((body == null ? void 0 : body.portal) === "agent") {
      setCookie(event, "mynet_agent_logged_out", "1", { path: "/", httpOnly: false });
    } else {
      setCookie(event, "mynet_admin_logged_out", "1", { path: "/", httpOnly: false });
    }
    return ok({ signedOut: true });
  }
  if (path === "/admin/overview" && method === "GET") {
    const liveZones = db.zones.filter((z) => z.status === "LIVE");
    const onlineDevices = db.devices.filter((d) => d.status === "ONLINE").length;
    const activeSubscribers = db.subscribers.filter((s) => s.status === "ACTIVE").length;
    const concurrentSessions = db.zones.reduce((sum, z) => sum + z.activeSessions, 0);
    const monthlyRevenue = db.zones.reduce((sum, z) => sum + z.monthlyRevenue, 0);
    const openAlerts = db.alerts.filter((a) => !a.resolvedAt);
    const openTickets = db.tickets.filter((t) => t.status === "OPEN" || t.status === "IN_PROGRESS");
    const availableVouchers = db.vouchers.filter((v) => v.status === "AVAILABLE" || v.status === "ASSIGNED").length;
    const outboxBacklog = db.outbox.filter((o) => o.status !== "DONE").length;
    return ok({
      kpis: {
        liveZones: liveZones.length,
        totalZones: db.zones.length,
        onlineDevices,
        totalDevices: db.devices.length,
        activeSubscribers,
        totalSubscribers: db.subscribers.length,
        concurrentSessions,
        monthlyRevenue,
        openAlerts: openAlerts.length,
        criticalAlerts: openAlerts.filter((a) => a.severity === "CRITICAL").length,
        openTickets: openTickets.length,
        availableVouchers,
        activeAgents: db.agents.filter((a) => a.status === "ACTIVE").length,
        outboxBacklog,
        totalDownMbps: Number(db.zones.reduce((sum, z) => sum + z.currentDownMbps, 0).toFixed(1)),
        totalCapacityMbps: db.zones.reduce((sum, z) => sum + z.upstreamDownMbps, 0)
      },
      zones: db.zones,
      alerts: openAlerts.slice(0, 5),
      recentTransactions: db.transactions.slice(0, 6),
      bandwidthSeries: db.bandwidthSeries,
      revenueSeries: db.revenueSeries
    });
  }
  if (path === "/admin/zones" && method === "GET") {
    return ok({
      zones: db.zones,
      costs: db.zoneCosts
    });
  }
  if (path === "/admin/zones" && method === "POST") {
    const body = await readBody(event);
    const zoneCode = String(body.zoneCode || "").trim().toUpperCase();
    const name = String(body.name || "").trim();
    if (!zoneCode || !name) {
      throw createError({ statusCode: 400, statusMessage: "Zone code and zone name are required." });
    }
    const created = {
      id: nextMockId("zone"),
      zoneCode,
      name,
      district: String(body.district || "Accra Metro"),
      region: String(body.region || "Greater Accra"),
      status: body.status || "PLANNED",
      backhaulProvider: String(body.backhaulProvider || "MTN_FIBRE"),
      backhaulCircuitRef: String(body.backhaulCircuitRef || `CIR-${zoneCode}-01`),
      upstreamDownMbps: Number(body.upstreamDownMbps || 100),
      upstreamUpMbps: Number(body.upstreamUpMbps || 50),
      upstreamMonthlyCost: Number(body.upstreamMonthlyCost || 1e3),
      upstreamIsCgnat: Boolean((_b = body.upstreamIsCgnat) != null ? _b : true),
      tunnelIp: String(body.tunnelIp || `10.200.1.${50 + db.zones.length}`),
      gpsLat: Number(body.gpsLat || 5.56),
      gpsLng: Number(body.gpsLng || -0.21),
      onlineDevices: 0,
      totalDevices: 0,
      activeSessions: 0,
      activeSubscribers: 0,
      currentDownMbps: 0,
      currentUpMbps: 0,
      monthlyRevenue: 0,
      notes: String(body.notes || "")
    };
    db.zones.unshift(created);
    db.auditLog.unshift({
      id: nextMockId("aud"),
      actorType: "STAFF",
      actorName: "Nana Kwame Admin",
      action: "ZONE_CREATED",
      entity: "magma_zones",
      entityId: created.id,
      summary: `Created zone ${created.name} (${created.zoneCode})`,
      ipAddress: "10.200.0.1",
      createdAt: (/* @__PURE__ */ new Date()).toISOString()
    });
    return ok(created, `Zone ${created.name} created.`);
  }
  const zoneUpdateMatch = path.match(/^\/admin\/zones\/([^/]+)$/);
  if (zoneUpdateMatch && method === "PUT") {
    const zone = db.zones.find((z) => z.id === zoneUpdateMatch[1]);
    if (!zone) throw createError({ statusCode: 404, statusMessage: "Zone not found." });
    const body = await readBody(event);
    Object.assign(zone, {
      name: (_c = body.name) != null ? _c : zone.name,
      district: (_d = body.district) != null ? _d : zone.district,
      status: (_e = body.status) != null ? _e : zone.status,
      backhaulProvider: (_f = body.backhaulProvider) != null ? _f : zone.backhaulProvider,
      upstreamDownMbps: body.upstreamDownMbps !== void 0 ? Number(body.upstreamDownMbps) : zone.upstreamDownMbps,
      upstreamUpMbps: body.upstreamUpMbps !== void 0 ? Number(body.upstreamUpMbps) : zone.upstreamUpMbps,
      upstreamMonthlyCost: body.upstreamMonthlyCost !== void 0 ? Number(body.upstreamMonthlyCost) : zone.upstreamMonthlyCost,
      tunnelIp: (_g = body.tunnelIp) != null ? _g : zone.tunnelIp,
      notes: (_h = body.notes) != null ? _h : zone.notes
    });
    if (zone.status === "CLOSED" || zone.status === "MAINTENANCE") {
      zone.activeSessions = 0;
      zone.currentDownMbps = 0;
      zone.currentUpMbps = 0;
    }
    return ok(zone, `Zone ${zone.name} updated to ${zone.status}.`);
  }
  const zoneCostMatch = path.match(/^\/admin\/zones\/([^/]+)\/costs$/);
  if (zoneCostMatch && method === "POST") {
    const zone = db.zones.find((z) => z.id === zoneCostMatch[1]);
    if (!zone) throw createError({ statusCode: 404, statusMessage: "Zone not found." });
    const body = await readBody(event);
    const cost = {
      id: nextMockId("cost"),
      zoneId: zone.id,
      zoneName: zone.name,
      category: body.category || "BACKHAUL",
      vendor: String(body.vendor || "Vendor"),
      reference: String(body.reference || `COST-${Date.now().toString().slice(-4)}`),
      amount: Number(body.amount || 0),
      periodStart: String(body.periodStart || "2026-11-01"),
      periodEnd: String(body.periodEnd || "2026-11-30"),
      notes: String(body.notes || "")
    };
    db.zoneCosts.unshift(cost);
    return ok(cost, "Operating cost recorded for zone P&L.");
  }
  if (path === "/admin/devices" && method === "GET") {
    const zoneId = String(query.zoneId || "");
    const list = zoneId ? db.devices.filter((d) => d.zoneId === zoneId) : db.devices;
    return ok(list);
  }
  if (path === "/admin/devices" && method === "POST") {
    const body = await readBody(event);
    const zone = db.zones.find((z) => z.id === body.zoneId) || db.zones[0];
    const created = {
      id: nextMockId("dev"),
      zoneId: zone.id,
      zoneName: zone.name,
      zoneCode: zone.zoneCode,
      name: String(body.name || "New RouterOS Node"),
      role: body.role || "AP",
      vendor: "MikroTik",
      model: String(body.model || "mANTBox ax 15s"),
      serialNumber: String(body.serialNumber || `MYN-SN-${Date.now().toString().slice(-5)}`),
      macAddress: String(body.macAddress || "48:8F:5A:24:09:99").toUpperCase(),
      routerosVersion: "7.16.2",
      managementIp: String(body.managementIp || "192.168.89.30"),
      tunnelIp: String(body.tunnelIp || "10.200.1.35"),
      restScheme: "http",
      restPort: 80,
      apiUsername: String(body.apiUsername || "magma-api"),
      enrolmentStatus: "ENROLLED",
      status: "ONLINE",
      lastSeenAt: (/* @__PURE__ */ new Date()).toISOString(),
      uptimeSeconds: 120,
      cpuLoad: 9,
      freeMemoryMb: 210,
      activeClients: 0,
      poeMode: String(body.poeMode || "24V Passive PoE"),
      notes: String(body.notes || "")
    };
    db.devices.unshift(created);
    zone.totalDevices += 1;
    zone.onlineDevices += 1;
    return ok(created, `Device ${created.name} registered & enrolled in RADIUS NAS.`);
  }
  if (path === "/admin/devices/poll" && method === "POST") {
    db.devices.forEach((d) => {
      if (d.status === "ONLINE") {
        d.lastSeenAt = (/* @__PURE__ */ new Date()).toISOString();
        d.uptimeSeconds += 60;
        d.cpuLoad = Math.max(6, Math.min(68, d.cpuLoad + (Math.random() > 0.5 ? 2 : -2)));
      }
    });
    return ok({ polled: db.devices.length }, "RouterOS REST fleet poll completed over WireGuard.");
  }
  const deviceActionMatch = path.match(/^\/admin\/devices\/([^/]+)\/(config|reboot|diagnostics)$/);
  if (deviceActionMatch) {
    const dev = db.devices.find((d) => d.id === deviceActionMatch[1]);
    if (!dev) throw createError({ statusCode: 404, statusMessage: "Device not found." });
    const action = deviceActionMatch[2];
    if (action === "config" && method === "POST") {
      dev.enrolmentStatus = "ENROLLED";
      dev.status = "ONLINE";
      dev.lastSeenAt = (/* @__PURE__ */ new Date()).toISOString();
      return ok({
        deviceId: dev.id,
        steps: [
          { step: "wireguard_peer", status: "ok", detail: `Tunnel ${dev.tunnelIp} keepalive=25s` },
          { step: "radius_client", status: "ok", detail: "Primary NAS 10.200.0.2 UDP/1812+1813, CoA 3799" },
          { step: "walled_garden", status: "ok", detail: "Portal + Hubtel + Paystack TLS hosts permitted" },
          { step: "hotspot_profile", status: "ok", detail: "MyNet SSID + 20MHz airtime fairness pushed" }
        ]
      }, `RouterOS configuration pushed to ${dev.name}.`);
    }
    if (action === "reboot" && method === "POST") {
      dev.uptimeSeconds = 15;
      dev.lastSeenAt = (/* @__PURE__ */ new Date()).toISOString();
      dev.status = "ONLINE";
      return ok(dev, `Reboot command accepted by ${dev.name}.`);
    }
    if (action === "diagnostics" && method === "GET") {
      return ok({
        device: dev,
        pingMs: dev.status === "ONLINE" ? 14.2 : null,
        wireguardHandshakeAgoSec: dev.status === "ONLINE" ? 11 : null,
        coaPortOpen: dev.status === "ONLINE",
        voltage: dev.poeMode.includes("24V") ? "24.2 V" : "26.8 V",
        temperatureC: dev.status === "ONLINE" ? 43 : null,
        wlan2GhzChannel: "2412 MHz (Ch 1 \xB7 20MHz)",
        wlan5GhzChannel: "5180 MHz (Ch 36 \xB7 20MHz)"
      });
    }
  }
  if (path === "/admin/plans" && method === "GET") {
    return ok(db.plans);
  }
  if (path === "/admin/plans" && method === "POST") {
    const body = await readBody(event);
    const planCode = String(body.planCode || "").trim().toUpperCase();
    if (!planCode || !body.name) {
      throw createError({ statusCode: 400, statusMessage: "Plan code and name are required." });
    }
    const price = Number(body.price || 10);
    const wholesalePrice = Number(body.wholesalePrice || (price * 0.85).toFixed(2));
    const plan = {
      id: nextMockId("plan"),
      planCode,
      name: String(body.name),
      planType: body.planType || "VOLUME",
      durationMinutes: Number(body.durationMinutes || 1440),
      dataCapMb: Number(body.dataCapMb || 5120),
      fairUseCapMb: Number(body.fairUseCapMb || 0),
      downKbps: Number(body.downKbps || 15e3),
      upKbps: Number(body.upKbps || 8e3),
      throttleDownKbps: Number(body.throttleDownKbps || 0),
      throttleUpKbps: Number(body.throttleUpKbps || 0),
      burstDownKbps: Number(body.burstDownKbps || 2e4),
      burstUpKbps: Number(body.burstUpKbps || 1e4),
      deviceLimit: Number(body.deviceLimit || 1),
      price,
      wholesalePrice,
      agentCommission: Number((price - wholesalePrice).toFixed(2)),
      taxInclusive: Boolean((_i = body.taxInclusive) != null ? _i : true),
      validityDays: Number(body.validityDays || 7),
      isPublic: Boolean((_j = body.isPublic) != null ? _j : true),
      isActive: true,
      sortOrder: db.plans.length + 1,
      zoneIds: Array.isArray(body.zoneIds) && body.zoneIds.length ? body.zoneIds : db.zones.map((z) => z.id),
      activeSubscriptions: 0,
      vouchersAvailable: 0
    };
    db.plans.push(plan);
    return ok(plan, `Plan ${plan.name} added to MyNet catalogue.`);
  }
  const planUpdateMatch = path.match(/^\/admin\/plans\/([^/]+)$/);
  if (planUpdateMatch && method === "PUT") {
    const plan = db.plans.find((p) => p.id === planUpdateMatch[1]);
    if (!plan) throw createError({ statusCode: 404, statusMessage: "Plan not found." });
    const body = await readBody(event);
    const price = body.price !== void 0 ? Number(body.price) : plan.price;
    const wholesalePrice = body.wholesalePrice !== void 0 ? Number(body.wholesalePrice) : plan.wholesalePrice;
    Object.assign(plan, {
      name: (_k = body.name) != null ? _k : plan.name,
      planType: (_l = body.planType) != null ? _l : plan.planType,
      durationMinutes: body.durationMinutes !== void 0 ? Number(body.durationMinutes) : plan.durationMinutes,
      dataCapMb: body.dataCapMb !== void 0 ? Number(body.dataCapMb) : plan.dataCapMb,
      downKbps: body.downKbps !== void 0 ? Number(body.downKbps) : plan.downKbps,
      upKbps: body.upKbps !== void 0 ? Number(body.upKbps) : plan.upKbps,
      deviceLimit: body.deviceLimit !== void 0 ? Number(body.deviceLimit) : plan.deviceLimit,
      price,
      wholesalePrice,
      agentCommission: Number((price - wholesalePrice).toFixed(2)),
      isPublic: body.isPublic !== void 0 ? Boolean(body.isPublic) : plan.isPublic,
      isActive: body.isActive !== void 0 ? Boolean(body.isActive) : plan.isActive
    });
    return ok(plan, `Plan ${plan.planCode} updated.`);
  }
  if (path === "/admin/subscribers" && method === "GET") {
    return ok({
      subscribers: db.subscribers,
      sessions: db.sessions,
      clientDevices: db.clientDevices
    });
  }
  if (path === "/admin/subscribers" && method === "POST") {
    const body = await readBody(event);
    const zone = db.zones.find((z) => z.id === body.homeZoneId) || db.zones[0];
    const plan = db.plans.find((p) => p.planCode === body.planCode) || db.plans[1];
    const authType = body.authType || (body.subscriberType === "RESIDENTIAL" ? "PPPOE" : "HOTSPOT");
    const created = {
      id: nextMockId("sub"),
      msisdn: String(body.msisdn || "").trim(),
      fullName: String(body.fullName || "New MyNet Subscriber").trim(),
      email: String(body.email || ""),
      ghanaCardMasked: body.ghanaCardNumber ? `GHA-*****${String(body.ghanaCardNumber).slice(-4)}` : void 0,
      subscriberType: body.subscriberType || "WALK_IN",
      authType,
      pppoeUsername: authType === "PPPOE" ? `mg-pppoe-${Date.now().toString().slice(-3)}` : void 0,
      homeZoneId: zone.id,
      homeZoneName: zone.name,
      serviceAddress: String(body.serviceAddress || zone.name),
      status: "ACTIVE",
      kycStatus: body.ghanaCardNumber ? "VERIFIED" : "NOT_REQUIRED",
      activePlanCode: plan.planCode,
      activePlanName: plan.name,
      subscriptionId: nextMockId("subs"),
      subscriptionStatus: "ACTIVE",
      usedMb: 0,
      purchasedMb: plan.dataCapMb || 256e3,
      expiresAt: new Date(Date.now() + plan.validityDays * 864e5).toISOString(),
      onlineNow: false,
      deviceCount: 1,
      lifetimeSpend: plan.price,
      lastSeenAt: (/* @__PURE__ */ new Date()).toISOString(),
      createdAt: (/* @__PURE__ */ new Date()).toISOString()
    };
    db.subscribers.unshift(created);
    return ok(created, `Subscriber ${created.fullName} onboarded & projected to FreeRADIUS.`);
  }
  const subActionMatch = path.match(/^\/admin\/subscribers\/([^/]+)\/(suspend|resume|extend|disconnect)$/);
  if (subActionMatch && method === "POST") {
    const sub = db.subscribers.find((s) => s.id === subActionMatch[1]);
    if (!sub) throw createError({ statusCode: 404, statusMessage: "Subscriber not found." });
    const action = subActionMatch[2];
    if (action === "suspend") {
      sub.status = "SUSPENDED";
      sub.subscriptionStatus = "SUSPENDED";
      sub.onlineNow = false;
      db.sessions = db.sessions.filter((s) => s.subscriberId !== sub.id);
      return ok(sub, `${sub.fullName} suspended & CoA Disconnect-Request sent.`);
    }
    if (action === "resume") {
      sub.status = "ACTIVE";
      sub.subscriptionStatus = "ACTIVE";
      return ok(sub, `${sub.fullName} restored in radcheck.`);
    }
    if (action === "extend") {
      const body = await readBody(event).catch(() => ({}));
      const extraDays = Number((body == null ? void 0 : body.days) || 3);
      const base = sub.expiresAt ? new Date(sub.expiresAt).getTime() : Date.now();
      sub.expiresAt = new Date(Math.max(Date.now(), base) + extraDays * 864e5).toISOString();
      sub.status = "ACTIVE";
      sub.subscriptionStatus = "ACTIVE";
      return ok(sub, `Subscription extended by ${extraDays} day(s).`);
    }
    if (action === "disconnect") {
      sub.onlineNow = false;
      db.sessions = db.sessions.filter((s) => s.subscriberId !== sub.id);
      return ok(sub, `Active RADIUS session terminated via CoA UDP/3799.`);
    }
  }
  const macToggleMatch = path.match(/^\/admin\/client-devices\/([^/]+)\/toggle-block$/);
  if (macToggleMatch && method === "POST") {
    const cdev = db.clientDevices.find((d) => d.id === macToggleMatch[1]);
    if (!cdev) throw createError({ statusCode: 404, statusMessage: "Client device not found." });
    cdev.isBlocked = !cdev.isBlocked;
    cdev.blockedReason = cdev.isBlocked ? "Blocked by Admin Operator" : void 0;
    return ok(cdev, cdev.isBlocked ? `MAC ${cdev.macAddress} blocked.` : `MAC ${cdev.macAddress} unblocked.`);
  }
  if (path === "/admin/vouchers" && method === "GET") {
    return ok({
      batches: db.voucherBatches,
      vouchers: db.vouchers
    });
  }
  if (path === "/admin/vouchers/batches" && method === "POST") {
    const body = await readBody(event);
    const plan = db.plans.find((p) => p.id === body.planId || p.planCode === body.planCode) || db.plans[1];
    const zone = db.zones.find((z) => z.id === body.zoneId) || db.zones[0];
    const qty = Math.max(1, Math.min(100, Number(body.quantity || 10)));
    const agent = body.ownerAgentId ? db.agents.find((a) => a.id === body.ownerAgentId) : null;
    const batchId = nextMockId("batch");
    const batchCode = `MYN-VB-${String(db.voucherBatches.length + 101)}`;
    const expiresAt = new Date(Date.now() + Number(body.expiresInDays || 90) * 864e5).toISOString();
    const batch = {
      id: batchId,
      batchCode,
      planId: plan.id,
      planCode: plan.planCode,
      planName: plan.name,
      zoneId: zone.id,
      zoneName: zone.name,
      quantity: qty,
      availableCount: agent ? 0 : qty,
      assignedCount: agent ? qty : 0,
      soldCount: 0,
      redeemedCount: 0,
      voidCount: 0,
      unitPrice: plan.price,
      wholesalePrice: plan.wholesalePrice,
      ownerType: agent ? "AGENT" : "BUSINESS",
      ownerAgentId: (agent == null ? void 0 : agent.id) || null,
      ownerAgentName: (agent == null ? void 0 : agent.name) || null,
      status: "ACTIVE",
      expiresAt,
      createdAt: (/* @__PURE__ */ new Date()).toISOString()
    };
    db.voucherBatches.unshift(batch);
    const baseSeed = Date.now() % 1e4;
    for (let i = 1; i <= qty; i++) {
      const serialNum = baseSeed + i + db.vouchers.length;
      db.vouchers.unshift({
        id: nextMockId("vch"),
        batchId: batch.id,
        batchCode: batch.batchCode,
        planId: plan.id,
        planCode: plan.planCode,
        planName: plan.name,
        allowanceLabel: `${plan.validityDays}d \xB7 ${plan.dataCapMb ? `${Math.round(plan.dataCapMb / 1024)} GB` : "Unlimited"}`,
        zoneId: zone.id,
        zoneName: zone.name,
        zoneCode: zone.zoneCode,
        serial: `SN-${serialNum}`,
        code: generateVoucherCode(plan.planCode, serialNum),
        status: agent ? "ASSIGNED" : "AVAILABLE",
        agentId: (agent == null ? void 0 : agent.id) || null,
        agentName: (agent == null ? void 0 : agent.name) || null,
        price: plan.price,
        wholesalePrice: plan.wholesalePrice,
        commission: plan.agentCommission,
        expiresAt,
        createdAt: batch.createdAt
      });
    }
    if (agent) recomputeAgentStock(db, agent.id);
    plan.vouchersAvailable += qty;
    return ok(batch, `Issued ${qty} HMAC-protected vouchers in ${batch.batchCode}.`);
  }
  const batchActionMatch = path.match(/^\/admin\/vouchers\/batches\/([^/]+)\/(assign|void)$/);
  if (batchActionMatch && method === "POST") {
    const batch = db.voucherBatches.find((b) => b.id === batchActionMatch[1]);
    if (!batch) throw createError({ statusCode: 404, statusMessage: "Voucher batch not found." });
    const action = batchActionMatch[2];
    if (action === "assign") {
      const body = await readBody(event);
      const agent = db.agents.find((a) => a.id === body.agentId);
      if (!agent) throw createError({ statusCode: 404, statusMessage: "Target agent not found." });
      batch.ownerType = "AGENT";
      batch.ownerAgentId = agent.id;
      batch.ownerAgentName = agent.name;
      db.vouchers.forEach((v) => {
        if (v.batchId === batch.id && v.status === "AVAILABLE") {
          v.status = "ASSIGNED";
          v.agentId = agent.id;
          v.agentName = agent.name;
        }
      });
      recomputeBatchCounts(db, batch.id);
      recomputeAgentStock(db, agent.id);
      return ok(batch, `Assigned available stock in ${batch.batchCode} to ${agent.name}.`);
    }
    if (action === "void") {
      batch.status = "VOID";
      db.vouchers.forEach((v) => {
        if (v.batchId === batch.id && (v.status === "AVAILABLE" || v.status === "ASSIGNED")) {
          v.status = "VOID";
        }
      });
      recomputeBatchCounts(db, batch.id);
      if (batch.ownerAgentId) recomputeAgentStock(db, batch.ownerAgentId);
      return ok(batch, `Unredeemed vouchers in ${batch.batchCode} voided.`);
    }
  }
  if (path === "/admin/agents" && method === "GET") {
    return ok({
      agents: db.agents,
      ledger: db.agentLedger
    });
  }
  if (path === "/admin/agents" && method === "POST") {
    const body = await readBody(event);
    const zone = db.zones.find((z) => z.id === body.territoryZoneId) || db.zones[0];
    const openingFloat = Number(body.openingFloat || 200);
    const created = {
      id: nextMockId("agent"),
      agentCode: `MYN-AG-00${db.agents.length + 1}`,
      name: String(body.name || "New MyNet Agent"),
      msisdn: String(body.msisdn || ""),
      email: String(body.email || ""),
      tier: body.tier || "STANDARD",
      commissionRate: Number(body.commissionRate || 0.12),
      territoryZoneId: zone.id,
      territoryZoneName: zone.name,
      territoryZoneCode: zone.zoneCode,
      walletAccountId: `TL-WAL-00${300 + db.agents.length}`,
      floatBalance: openingFloat,
      commissionEarnedMonth: 0,
      vouchersInStock: 0,
      vouchersSoldMonth: 0,
      status: "ACTIVE",
      kycStatus: "VERIFIED",
      createdAt: (/* @__PURE__ */ new Date()).toISOString()
    };
    db.agents.unshift(created);
    if (openingFloat > 0) {
      db.agentLedger.unshift({
        id: nextMockId("led"),
        agentId: created.id,
        agentName: created.name,
        entryType: "ADJUSTMENT",
        amount: openingFloat,
        balanceAfter: openingFloat,
        reference: `MYN-OPEN-${created.agentCode}`,
        description: "Opening float wallet credit",
        provider: "WALLET",
        status: "COMPLETED",
        createdAt: (/* @__PURE__ */ new Date()).toISOString()
      });
    }
    return ok(created, `Agent ${created.name} onboarded (${created.agentCode}).`);
  }
  const agentAdminAction = path.match(/^\/admin\/agents\/([^/]+)\/(topup|settle|toggle-status)$/);
  if (agentAdminAction && method === "POST") {
    const agent = db.agents.find((a) => a.id === agentAdminAction[1]);
    if (!agent) throw createError({ statusCode: 404, statusMessage: "Agent not found." });
    const action = agentAdminAction[2];
    const body = await readBody(event).catch(() => ({}));
    if (action === "toggle-status") {
      agent.status = agent.status === "ACTIVE" ? "SUSPENDED" : "ACTIVE";
      return ok(agent, `Agent ${agent.name} is now ${agent.status}.`);
    }
    const amount = Number(body.amount || 0);
    if (amount <= 0) throw createError({ statusCode: 400, statusMessage: "Enter a positive amount." });
    if (action === "topup") {
      agent.floatBalance = Number((agent.floatBalance + amount).toFixed(2));
      db.agentLedger.unshift({
        id: nextMockId("led"),
        agentId: agent.id,
        agentName: agent.name,
        entryType: "FLOAT_TOPUP",
        amount,
        balanceAfter: agent.floatBalance,
        reference: `MYN-FLT-${Date.now().toString().slice(-4)}`,
        description: String(body.description || "Admin float credit"),
        provider: String(body.provider || "MOMO_MTN"),
        status: "COMPLETED",
        createdAt: (/* @__PURE__ */ new Date()).toISOString()
      });
      return ok(agent, `Credited GH\u20B5 ${amount.toFixed(2)} to ${agent.name}.`);
    }
    if (action === "settle") {
      if (amount > agent.floatBalance) {
        throw createError({ statusCode: 400, statusMessage: "Settlement exceeds agent wallet balance." });
      }
      agent.floatBalance = Number((agent.floatBalance - amount).toFixed(2));
      db.agentLedger.unshift({
        id: nextMockId("led"),
        agentId: agent.id,
        agentName: agent.name,
        entryType: "PAYOUT",
        amount: -amount,
        balanceAfter: agent.floatBalance,
        reference: `MYN-PAY-${Date.now().toString().slice(-4)}`,
        description: `MoMo payout settlement to ${agent.msisdn}`,
        provider: String(body.provider || "MOMO_MTN"),
        status: "COMPLETED",
        createdAt: (/* @__PURE__ */ new Date()).toISOString()
      });
      return ok(agent, `Disbursed GH\u20B5 ${amount.toFixed(2)} MoMo payout to ${agent.name}.`);
    }
  }
  if (path === "/admin/billing" && method === "GET") {
    const successful = db.transactions.filter((t) => t.status === "SUCCESS");
    const gross = successful.reduce((s, t) => s + t.amount, 0);
    const net = successful.reduce((s, t) => s + t.netAmount, 0);
    const tax = successful.reduce((s, t) => s + t.taxAmount, 0);
    const vat = successful.reduce((s, t) => s + t.taxBreakdown.vat, 0);
    const nhil = successful.reduce((s, t) => s + t.taxBreakdown.nhil, 0);
    const getFund = successful.reduce((s, t) => s + t.taxBreakdown.getFund, 0);
    return ok({
      summary: {
        grossRevenue: Number(gross.toFixed(2)),
        netRevenue: Number(net.toFixed(2)),
        totalTax: Number(tax.toFixed(2)),
        vat: Number(vat.toFixed(2)),
        nhil: Number(nhil.toFixed(2)),
        getFund: Number(getFund.toFixed(2)),
        pendingCount: db.transactions.filter((t) => t.status === "PENDING").length,
        overdueInvoices: db.invoices.filter((i) => i.status === "OVERDUE").length
      },
      transactions: db.transactions,
      invoices: db.invoices,
      revenueSeries: db.revenueSeries
    });
  }
  const txActionMatch = path.match(/^\/admin\/transactions\/([^/]+)\/(verify|refund)$/);
  if (txActionMatch && method === "POST") {
    const tx = db.transactions.find((t) => t.id === txActionMatch[1]);
    if (!tx) throw createError({ statusCode: 404, statusMessage: "Transaction not found." });
    if (txActionMatch[2] === "verify") {
      tx.status = "SUCCESS";
      tx.paidAt = (/* @__PURE__ */ new Date()).toISOString();
      return ok(tx, `Transaction ${tx.internalReference} verified with ${tx.provider} & provisioned.`);
    }
    tx.status = "REVERSED";
    return ok(tx, `Transaction ${tx.internalReference} refunded & subscription revoked.`);
  }
  if (path === "/admin/invoices/run" && method === "POST") {
    const pppoeSubs = db.subscribers.filter((s) => s.authType === "PPPOE" && s.status === "ACTIVE");
    const createdCount = pppoeSubs.length;
    if (pppoeSubs[0]) {
      db.invoices.unshift({
        id: nextMockId("inv"),
        subscriberId: pppoeSubs[0].id,
        subscriberName: pppoeSubs[0].fullName,
        msisdn: pppoeSubs[0].msisdn,
        subscriptionId: pppoeSubs[0].subscriptionId || "subs-new",
        planName: pppoeSubs[0].activePlanName || "MyNet Home & Shop Monthly",
        zoneName: pppoeSubs[0].homeZoneName,
        invoiceNumber: `INV-MYN-00${45 + db.invoices.length}`,
        periodStart: "2026-12-01",
        periodEnd: "2026-12-31",
        subtotal: 100,
        taxAmount: 20,
        total: 120,
        amountPaid: 0,
        status: "ISSUED",
        dueAt: new Date(Date.now() + 7 * 864e5).toISOString(),
        issuedAt: (/* @__PURE__ */ new Date()).toISOString(),
        paidAt: null
      });
    }
    return ok({ generated: createdCount }, `Monthly PPPoE billing run issued ${createdCount} invoice(s).`);
  }
  if (path === "/admin/monitoring" && method === "GET") {
    return ok({
      health: {
        api: "HEALTHY",
        postgres: "HEALTHY",
        redis: "HEALTHY",
        freeradiusPrimary: "HEALTHY",
        freeradiusStandby: "HEALTHY",
        wireguardHub: "HEALTHY",
        radiusAuthP95Ms: 84,
        coaDeliveryPct: 99.4
      },
      alerts: db.alerts,
      outbox: db.outbox,
      bandwidthSeries: db.bandwidthSeries
    });
  }
  const alertActionMatch = path.match(/^\/admin\/alerts\/([^/]+)\/(ack|resolve)$/);
  if (alertActionMatch && method === "POST") {
    const alert = db.alerts.find((a) => a.id === alertActionMatch[1]);
    if (!alert) throw createError({ statusCode: 404, statusMessage: "Alert not found." });
    if (alertActionMatch[2] === "ack") {
      alert.acknowledgedBy = "Nana Kwame Admin";
      alert.acknowledgedAt = (/* @__PURE__ */ new Date()).toISOString();
      return ok(alert, "Alert acknowledged.");
    }
    alert.resolvedAt = (/* @__PURE__ */ new Date()).toISOString();
    if (!alert.acknowledgedAt) {
      alert.acknowledgedBy = "Nana Kwame Admin";
      alert.acknowledgedAt = alert.resolvedAt;
    }
    return ok(alert, "Alert marked resolved.");
  }
  if (path === "/admin/outbox/drain" && method === "POST") {
    let processed = 0;
    db.outbox.forEach((ev) => {
      if (ev.status !== "DONE") {
        ev.status = "DONE";
        ev.lastError = null;
        ev.processedAt = (/* @__PURE__ */ new Date()).toISOString();
        processed += 1;
      }
    });
    return ok({ processed }, `Outbox worker drained ${processed} pending/dead-letter event(s).`);
  }
  if (path === "/admin/support" && method === "GET") {
    return ok({
      tickets: db.tickets,
      workOrders: db.workOrders,
      staff: db.staff
    });
  }
  if (path === "/admin/tickets" && method === "POST") {
    const body = await readBody(event);
    const zone = db.zones.find((z) => z.id === body.zoneId) || db.zones[0];
    const tkt = {
      id: nextMockId("tkt"),
      ticketNumber: `TKT-${2044 + db.tickets.length}`,
      zoneId: zone.id,
      zoneName: zone.name,
      subscriberName: body.subscriberName || "Walk-in Subscriber",
      subscriberMsisdn: body.subscriberMsisdn || "",
      category: body.category || "CONNECTIVITY",
      priority: body.priority || "NORMAL",
      status: "OPEN",
      subject: String(body.subject || "Support issue"),
      description: String(body.description || ""),
      assignedTo: "staff-support",
      assignedToName: "Esi Helpdesk Lead",
      slaDueAt: new Date(Date.now() + 24 * 36e5).toISOString(),
      createdAt: (/* @__PURE__ */ new Date()).toISOString(),
      updatedAt: (/* @__PURE__ */ new Date()).toISOString(),
      messages: [
        {
          id: nextMockId("tm"),
          ticketId: "",
          authorType: "STAFF",
          authorName: "Helpdesk Intake",
          body: String(body.description || "Ticket logged."),
          createdAt: (/* @__PURE__ */ new Date()).toISOString()
        }
      ]
    };
    tkt.messages[0].ticketId = tkt.id;
    db.tickets.unshift(tkt);
    return ok(tkt, `Ticket ${tkt.ticketNumber} opened.`);
  }
  const ticketReplyMatch = path.match(/^\/admin\/tickets\/([^/]+)\/reply$/);
  if (ticketReplyMatch && method === "POST") {
    const tkt = db.tickets.find((t) => t.id === ticketReplyMatch[1]);
    if (!tkt) throw createError({ statusCode: 404, statusMessage: "Ticket not found." });
    const body = await readBody(event);
    if (body.message) {
      tkt.messages.push({
        id: nextMockId("tm"),
        ticketId: tkt.id,
        authorType: body.authorType || "STAFF",
        authorName: body.authorName || "Nana Kwame Admin",
        body: String(body.message),
        createdAt: (/* @__PURE__ */ new Date()).toISOString()
      });
    }
    if (body.status) {
      tkt.status = body.status;
      if (body.status === "RESOLVED" || body.status === "CLOSED") {
        tkt.resolvedAt = (/* @__PURE__ */ new Date()).toISOString();
      }
    }
    tkt.updatedAt = (/* @__PURE__ */ new Date()).toISOString();
    return ok(tkt, `Ticket ${tkt.ticketNumber} updated.`);
  }
  if (path === "/admin/work-orders" && method === "POST") {
    const body = await readBody(event);
    const zone = db.zones.find((z) => z.id === body.zoneId) || db.zones[0];
    const staffMember = db.staff.find((s) => s.id === body.assignedTo) || db.staff[2];
    const wo = {
      id: nextMockId("wo"),
      orderNumber: `WO-${1004 + db.workOrders.length}`,
      zoneId: zone.id,
      zoneName: zone.name,
      subscriberName: body.subscriberName || null,
      serviceAddress: String(body.serviceAddress || zone.name),
      orderType: body.orderType || "INSTALL",
      status: "SCHEDULED",
      assignedTo: staffMember.id,
      assignedToName: staffMember.fullName,
      scheduledAt: body.scheduledAt || new Date(Date.now() + 864e5).toISOString(),
      checklist: Array.isArray(body.checklist) && body.checklist.length ? body.checklist : ["Site safety & grounding check", "Verify 24V passive PoE voltage", "Confirm subscriber throughput"],
      materials: Array.isArray(body.materials) ? body.materials : [],
      cost: Number(body.cost || 0),
      completedAt: null,
      createdAt: (/* @__PURE__ */ new Date()).toISOString()
    };
    db.workOrders.unshift(wo);
    return ok(wo, `Work order ${wo.orderNumber} scheduled.`);
  }
  const woStatusMatch = path.match(/^\/admin\/work-orders\/([^/]+)\/status$/);
  if (woStatusMatch && method === "POST") {
    const wo = db.workOrders.find((w) => w.id === woStatusMatch[1]);
    if (!wo) throw createError({ statusCode: 404, statusMessage: "Work order not found." });
    const body = await readBody(event);
    wo.status = body.status || "DONE";
    if (wo.status === "DONE") wo.completedAt = (/* @__PURE__ */ new Date()).toISOString();
    return ok(wo, `${wo.orderNumber} marked ${wo.status}.`);
  }
  if (path === "/admin/system" && method === "GET") {
    return ok({
      business: db.business,
      staff: db.staff,
      auditLog: db.auditLog
    });
  }
  if (path === "/admin/staff" && method === "POST") {
    const body = await readBody(event);
    const member = {
      id: nextMockId("staff"),
      fullName: String(body.fullName || "New Staff"),
      msisdn: String(body.msisdn || ""),
      email: String(body.email || ""),
      role: body.role || "SUPPORT",
      zoneIds: db.zones.map((z) => z.id),
      zoneNames: ["All Zones"],
      status: "ACTIVE",
      lastLoginAt: (/* @__PURE__ */ new Date()).toISOString(),
      createdAt: (/* @__PURE__ */ new Date()).toISOString()
    };
    db.staff.push(member);
    return ok(member, `${member.fullName} added to MyNet staff directory.`);
  }
  if (path === "/agent/dashboard" && method === "GET") {
    const agentId = getActiveAgentId(event, String(query.agentId || "agent-1"));
    const agent = db.agents.find((a) => a.id === agentId) || db.agents[0];
    recomputeAgentStock(db, agent.id);
    const agentVouchers = db.vouchers.filter((v) => v.agentId === agent.id);
    const soldVouchers = agentVouchers.filter((v) => v.status === "SOLD" || v.status === "REDEEMED");
    const stockByPlan = db.plans.map((p) => {
      const count = agentVouchers.filter((v) => v.planId === p.id && v.status === "ASSIGNED").length;
      return {
        planId: p.id,
        planCode: p.planCode,
        planName: p.name,
        price: p.price,
        wholesalePrice: p.wholesalePrice,
        commission: Number((p.price * agent.commissionRate).toFixed(2)),
        inStock: count
      };
    });
    const territoryZone = db.zones.find((z) => z.id === agent.territoryZoneId) || db.zones[0];
    const ledger = db.agentLedger.filter((l) => l.agentId === agent.id);
    return ok({
      agent,
      territoryZone,
      stockByPlan,
      recentSales: soldVouchers.slice(0, 8),
      recentLedger: ledger.slice(0, 6),
      dailySalesChart: [
        { day: "Mon", sales: 120, commission: 18 },
        { day: "Tue", sales: 168, commission: 25.2 },
        { day: "Wed", sales: 144, commission: 21.6 },
        { day: "Thu", sales: 216, commission: 32.4 },
        { day: "Fri", sales: 264, commission: 39.6 },
        { day: "Sat", sales: 312, commission: 46.8 },
        { day: "Sun", sales: 196, commission: 29.4 }
      ]
    });
  }
  if (path === "/agent/catalog" && method === "GET") {
    const agentId = getActiveAgentId(event);
    const agent = db.agents.find((a) => a.id === agentId) || db.agents[0];
    const plans = db.plans.filter((p) => p.isActive && p.isPublic).map((p) => {
      const inStock = db.vouchers.filter((v) => v.agentId === agent.id && v.planId === p.id && v.status === "ASSIGNED").length;
      const commission = Number((p.price * agent.commissionRate).toFixed(2));
      const netDebit = Number((p.price - commission).toFixed(2));
      return {
        ...p,
        inStock,
        effectiveCommission: commission,
        netFloatCost: netDebit
      };
    });
    return ok({
      agent,
      zones: db.zones.filter((z) => z.status === "LIVE"),
      plans
    });
  }
  if (path === "/agent/sell" && method === "POST") {
    const agentId = getActiveAgentId(event);
    const agent = db.agents.find((a) => a.id === agentId) || db.agents[0];
    const body = await readBody(event);
    const plan = db.plans.find((p) => p.id === body.planId || p.planCode === body.planCode);
    if (!plan) throw createError({ statusCode: 404, statusMessage: "Selected data bundle not found." });
    const zone = db.zones.find((z) => z.id === (body.zoneId || agent.territoryZoneId)) || db.zones[0];
    const source = body.source === "float" ? "float" : "stock";
    const customerMsisdn = String(body.customerMsisdn || "").trim();
    const customerName = String(body.customerName || "Walk-in Customer").trim();
    const stockedVoucher = db.vouchers.find(
      (v) => v.agentId === agent.id && v.planId === plan.id && v.status === "ASSIGNED"
    );
    const commission = Number((plan.price * agent.commissionRate).toFixed(2));
    const netCost = Number((plan.price - commission).toFixed(2));
    let soldVoucher = stockedVoucher;
    if (source === "stock" && stockedVoucher) {
      stockedVoucher.status = "SOLD";
      stockedVoucher.customerMsisdn = customerMsisdn || null;
      stockedVoucher.customerName = customerName;
      stockedVoucher.soldAt = (/* @__PURE__ */ new Date()).toISOString();
      recomputeBatchCounts(db, stockedVoucher.batchId);
      recomputeAgentStock(db, agent.id);
      agent.vouchersSoldMonth += 1;
      agent.commissionEarnedMonth = Number((agent.commissionEarnedMonth + stockedVoucher.commission).toFixed(2));
    } else {
      if (agent.floatBalance < netCost) {
        throw createError({
          statusCode: 400,
          statusMessage: `Insufficient float balance (need GH\u20B5 ${netCost.toFixed(2)}, have GH\u20B5 ${agent.floatBalance.toFixed(2)}). Top up your float first.`
        });
      }
      agent.floatBalance = Number((agent.floatBalance - netCost).toFixed(2));
      agent.vouchersSoldMonth += 1;
      agent.commissionEarnedMonth = Number((agent.commissionEarnedMonth + commission).toFixed(2));
      const serialSeed = Date.now() % 1e5;
      soldVoucher = {
        id: nextMockId("vch"),
        batchId: "instant-pos",
        batchCode: "INSTANT-POS",
        planId: plan.id,
        planCode: plan.planCode,
        planName: plan.name,
        allowanceLabel: `${plan.validityDays}d \xB7 ${plan.dataCapMb ? `${Math.round(plan.dataCapMb / 1024)} GB` : "Unlimited"}`,
        zoneId: zone.id,
        zoneName: zone.name,
        zoneCode: zone.zoneCode,
        serial: `POS-${serialSeed}`,
        code: generateVoucherCode(plan.planCode, serialSeed),
        status: "SOLD",
        agentId: agent.id,
        agentName: agent.name,
        price: plan.price,
        wholesalePrice: netCost,
        commission,
        customerMsisdn: customerMsisdn || null,
        customerName,
        soldAt: (/* @__PURE__ */ new Date()).toISOString(),
        expiresAt: new Date(Date.now() + 60 * 864e5).toISOString(),
        createdAt: (/* @__PURE__ */ new Date()).toISOString()
      };
      db.vouchers.unshift(soldVoucher);
      db.agentLedger.unshift({
        id: nextMockId("led"),
        agentId: agent.id,
        agentName: agent.name,
        entryType: "VOUCHER_SALE",
        amount: -netCost,
        balanceAfter: agent.floatBalance,
        reference: soldVoucher.serial,
        description: `Instant PIN ${plan.planCode} sold (${customerMsisdn || "Walk-in"}) \xB7 Earned GH\u20B5 ${commission.toFixed(2)}`,
        provider: "WALLET",
        status: "COMPLETED",
        createdAt: (/* @__PURE__ */ new Date()).toISOString()
      });
    }
    const netAmt = Number((plan.price / 1.2).toFixed(2));
    db.transactions.unshift({
      id: nextMockId("tx"),
      subscriberName: customerName,
      payerMsisdn: customerMsisdn || agent.msisdn,
      agentId: agent.id,
      agentName: agent.name,
      voucherId: soldVoucher.id,
      zoneId: zone.id,
      zoneName: zone.name,
      planCode: plan.planCode,
      planName: plan.name,
      purpose: "VOUCHER",
      amount: plan.price,
      netAmount: netAmt,
      taxAmount: Number((plan.price - netAmt).toFixed(2)),
      taxBreakdown: {
        vat: Number((netAmt * 0.15).toFixed(2)),
        nhil: Number((netAmt * 0.025).toFixed(2)),
        getFund: Number((netAmt * 0.025).toFixed(2))
      },
      paymentMethod: "CASH_FLOAT",
      provider: "WALLET",
      providerReference: soldVoucher.serial,
      internalReference: `MYN-POS-${soldVoucher.serial}`,
      status: "SUCCESS",
      initiatedAt: (/* @__PURE__ */ new Date()).toISOString(),
      paidAt: (/* @__PURE__ */ new Date()).toISOString()
    });
    return ok({
      voucher: soldVoucher,
      agent,
      portalRedeemUrl: `https://wifi.mynet.gh/?zone=${encodeURIComponent(zone.zoneCode)}&voucher=${encodeURIComponent(soldVoucher.code)}`
    }, `Voucher ${soldVoucher.code} issued!`);
  }
  if (path === "/agent/stock" && method === "GET") {
    const agentId = getActiveAgentId(event);
    const agent = db.agents.find((a) => a.id === agentId) || db.agents[0];
    recomputeAgentStock(db, agent.id);
    return ok({
      agent,
      vouchers: db.vouchers.filter((v) => v.agentId === agent.id),
      batches: db.voucherBatches.filter((b) => b.ownerAgentId === agent.id),
      plans: db.plans.filter((p) => p.isActive),
      zones: db.zones.filter((z) => z.status === "LIVE")
    });
  }
  if (path === "/agent/stock/purchase" && method === "POST") {
    const agentId = getActiveAgentId(event);
    const agent = db.agents.find((a) => a.id === agentId) || db.agents[0];
    const body = await readBody(event);
    const plan = db.plans.find((p) => p.id === body.planId || p.planCode === body.planCode);
    if (!plan) throw createError({ statusCode: 404, statusMessage: "Plan not found." });
    const qty = Math.max(1, Math.min(100, Number(body.quantity || 10)));
    const zone = db.zones.find((z) => z.id === (body.zoneId || agent.territoryZoneId)) || db.zones[0];
    const unitCost = Number((plan.price * (1 - agent.commissionRate)).toFixed(2));
    const totalCost = Number((unitCost * qty).toFixed(2));
    if (agent.floatBalance < totalCost) {
      throw createError({
        statusCode: 400,
        statusMessage: `Float balance GH\u20B5 ${agent.floatBalance.toFixed(2)} is below wholesale cost GH\u20B5 ${totalCost.toFixed(2)}.`
      });
    }
    agent.floatBalance = Number((agent.floatBalance - totalCost).toFixed(2));
    const batchId = nextMockId("batch");
    const batchCode = `MYN-AGB-${db.voucherBatches.length + 201}`;
    const expiresAt = new Date(Date.now() + 90 * 864e5).toISOString();
    const batch = {
      id: batchId,
      batchCode,
      planId: plan.id,
      planCode: plan.planCode,
      planName: plan.name,
      zoneId: zone.id,
      zoneName: zone.name,
      quantity: qty,
      availableCount: 0,
      assignedCount: qty,
      soldCount: 0,
      redeemedCount: 0,
      voidCount: 0,
      unitPrice: plan.price,
      wholesalePrice: unitCost,
      ownerType: "AGENT",
      ownerAgentId: agent.id,
      ownerAgentName: agent.name,
      status: "ACTIVE",
      expiresAt,
      createdAt: (/* @__PURE__ */ new Date()).toISOString()
    };
    db.voucherBatches.unshift(batch);
    const seed = Date.now() % 1e4;
    for (let i = 1; i <= qty; i++) {
      const n = seed + i + db.vouchers.length;
      db.vouchers.unshift({
        id: nextMockId("vch"),
        batchId: batch.id,
        batchCode: batch.batchCode,
        planId: plan.id,
        planCode: plan.planCode,
        planName: plan.name,
        allowanceLabel: `${plan.validityDays}d \xB7 ${plan.dataCapMb ? `${Math.round(plan.dataCapMb / 1024)} GB` : "Unlimited"}`,
        zoneId: zone.id,
        zoneName: zone.name,
        zoneCode: zone.zoneCode,
        serial: `SN-${n}`,
        code: generateVoucherCode(plan.planCode, n),
        status: "ASSIGNED",
        agentId: agent.id,
        agentName: agent.name,
        price: plan.price,
        wholesalePrice: unitCost,
        commission: Number((plan.price - unitCost).toFixed(2)),
        expiresAt,
        createdAt: batch.createdAt
      });
    }
    recomputeAgentStock(db, agent.id);
    db.agentLedger.unshift({
      id: nextMockId("led"),
      agentId: agent.id,
      agentName: agent.name,
      entryType: "STOCK_PURCHASE",
      amount: -totalCost,
      balanceAfter: agent.floatBalance,
      reference: batchCode,
      description: `Wholesale bundle stock: ${qty} \xD7 ${plan.planCode}`,
      provider: "WALLET",
      status: "COMPLETED",
      createdAt: (/* @__PURE__ */ new Date()).toISOString()
    });
    return ok({ batch, agent }, `Purchased ${qty} \xD7 ${plan.planCode} vouchers into your stock!`);
  }
  if (path === "/agent/wallet" && method === "GET") {
    const agentId = getActiveAgentId(event);
    const agent = db.agents.find((a) => a.id === agentId) || db.agents[0];
    return ok({
      agent,
      ledger: db.agentLedger.filter((l) => l.agentId === agent.id)
    });
  }
  if (path === "/agent/wallet/topup" && method === "POST") {
    const agentId = getActiveAgentId(event);
    const agent = db.agents.find((a) => a.id === agentId) || db.agents[0];
    const body = await readBody(event);
    const amount = Number(body.amount || 0);
    if (amount < 10) {
      throw createError({ statusCode: 400, statusMessage: "Minimum float top-up is GH\u20B5 10.00." });
    }
    agent.floatBalance = Number((agent.floatBalance + amount).toFixed(2));
    const entry = {
      id: nextMockId("led"),
      agentId: agent.id,
      agentName: agent.name,
      entryType: "FLOAT_TOPUP",
      amount,
      balanceAfter: agent.floatBalance,
      reference: `MYN-MOMO-${Date.now().toString().slice(-5)}`,
      description: `${body.provider || "MOMO_MTN"} float top-up from ${body.msisdn || agent.msisdn}`,
      provider: String(body.provider || "MOMO_MTN"),
      status: "COMPLETED",
      createdAt: (/* @__PURE__ */ new Date()).toISOString()
    };
    db.agentLedger.unshift(entry);
    return ok({ agent, entry }, `Float wallet topped up by GH\u20B5 ${amount.toFixed(2)}.`);
  }
  if (path === "/agent/wallet/settlement" && method === "POST") {
    const agentId = getActiveAgentId(event);
    const agent = db.agents.find((a) => a.id === agentId) || db.agents[0];
    const body = await readBody(event);
    const amount = Number(body.amount || 0);
    if (amount <= 0 || amount > agent.floatBalance) {
      throw createError({ statusCode: 400, statusMessage: "Enter a valid payout amount within your wallet balance." });
    }
    agent.floatBalance = Number((agent.floatBalance - amount).toFixed(2));
    const entry = {
      id: nextMockId("led"),
      agentId: agent.id,
      agentName: agent.name,
      entryType: "PAYOUT",
      amount: -amount,
      balanceAfter: agent.floatBalance,
      reference: `MYN-SET-${Date.now().toString().slice(-5)}`,
      description: `MoMo settlement payout to ${body.msisdn || agent.msisdn} (${body.provider || "MOMO_MTN"})`,
      provider: String(body.provider || "MOMO_MTN"),
      status: "COMPLETED",
      createdAt: (/* @__PURE__ */ new Date()).toISOString()
    };
    db.agentLedger.unshift(entry);
    return ok({ agent, entry }, `Payout of GH\u20B5 ${amount.toFixed(2)} sent to ${body.msisdn || agent.msisdn}.`);
  }
  if (path === "/agent/subscriber-lookup" && method === "GET") {
    const q = String(query.q || "").trim().toLowerCase();
    const matches = q ? db.subscribers.filter((s) => s.msisdn.includes(q) || s.fullName.toLowerCase().includes(q)) : db.subscribers.slice(0, 5);
    return ok({
      subscribers: matches,
      plans: db.plans.filter((p) => p.isActive && p.isPublic)
    });
  }
  if (path === "/agent/subscriber-topup" && method === "POST") {
    const agentId = getActiveAgentId(event);
    const agent = db.agents.find((a) => a.id === agentId) || db.agents[0];
    const body = await readBody(event);
    const plan = db.plans.find((p) => p.id === body.planId || p.planCode === body.planCode);
    if (!plan) throw createError({ statusCode: 404, statusMessage: "Plan not found." });
    const msisdn = String(body.msisdn || "").trim();
    if (!msisdn) throw createError({ statusCode: 400, statusMessage: "Subscriber phone number is required." });
    const commission = Number((plan.price * agent.commissionRate).toFixed(2));
    const netDebit = Number((plan.price - commission).toFixed(2));
    if (agent.floatBalance < netDebit) {
      throw createError({ statusCode: 400, statusMessage: "Insufficient float balance for direct top-up." });
    }
    let sub = db.subscribers.find((s) => s.msisdn === msisdn);
    if (!sub) {
      sub = {
        id: nextMockId("sub"),
        msisdn,
        fullName: String(body.fullName || `Walk-in (${msisdn})`),
        email: "",
        subscriberType: "WALK_IN",
        authType: "HOTSPOT",
        homeZoneId: agent.territoryZoneId,
        homeZoneName: agent.territoryZoneName,
        serviceAddress: agent.territoryZoneName,
        status: "ACTIVE",
        kycStatus: "NOT_REQUIRED",
        usedMb: 0,
        purchasedMb: plan.dataCapMb || 256e3,
        onlineNow: true,
        deviceCount: 1,
        lifetimeSpend: 0,
        lastSeenAt: (/* @__PURE__ */ new Date()).toISOString(),
        createdAt: (/* @__PURE__ */ new Date()).toISOString()
      };
      db.subscribers.unshift(sub);
    }
    sub.status = "ACTIVE";
    sub.subscriptionStatus = "ACTIVE";
    sub.activePlanCode = plan.planCode;
    sub.activePlanName = plan.name;
    sub.purchasedMb = plan.dataCapMb || 256e3;
    sub.usedMb = 0;
    sub.expiresAt = new Date(Date.now() + plan.validityDays * 864e5).toISOString();
    sub.lifetimeSpend += plan.price;
    agent.floatBalance = Number((agent.floatBalance - netDebit).toFixed(2));
    agent.commissionEarnedMonth = Number((agent.commissionEarnedMonth + commission).toFixed(2));
    db.agentLedger.unshift({
      id: nextMockId("led"),
      agentId: agent.id,
      agentName: agent.name,
      entryType: "VOUCHER_SALE",
      amount: -netDebit,
      balanceAfter: agent.floatBalance,
      reference: `TOPUP-${Date.now().toString().slice(-4)}`,
      description: `Direct bundle activation ${plan.planCode} for ${sub.fullName} (${msisdn})`,
      provider: "WALLET",
      status: "COMPLETED",
      createdAt: (/* @__PURE__ */ new Date()).toISOString()
    });
    return ok({ subscriber: sub, agent, commission }, `Activated ${plan.name} for ${sub.fullName} (${msisdn}).`);
  }
  if (path === "/agent/tickets" && method === "GET") {
    const agentId = getActiveAgentId(event);
    const agent = db.agents.find((a) => a.id === agentId) || db.agents[0];
    return ok({
      agent,
      zones: db.zones,
      tickets: db.tickets.filter((t) => t.agentId === agent.id || t.zoneId === agent.territoryZoneId)
    });
  }
  if (path === "/agent/tickets" && method === "POST") {
    const agentId = getActiveAgentId(event);
    const agent = db.agents.find((a) => a.id === agentId) || db.agents[0];
    const body = await readBody(event);
    const zone = db.zones.find((z) => z.id === (body.zoneId || agent.territoryZoneId)) || db.zones[0];
    const tkt = {
      id: nextMockId("tkt"),
      ticketNumber: `TKT-${2045 + db.tickets.length}`,
      zoneId: zone.id,
      zoneName: zone.name,
      agentId: agent.id,
      agentName: agent.name,
      subscriberMsisdn: body.subscriberMsisdn || null,
      category: body.category || "CONNECTIVITY",
      priority: body.priority || "HIGH",
      status: "OPEN",
      subject: String(body.subject || "Field issue reported by agent"),
      description: String(body.description || ""),
      assignedTo: "staff-support",
      assignedToName: "Esi Helpdesk Lead",
      slaDueAt: new Date(Date.now() + 12 * 36e5).toISOString(),
      createdAt: (/* @__PURE__ */ new Date()).toISOString(),
      updatedAt: (/* @__PURE__ */ new Date()).toISOString(),
      messages: [
        {
          id: nextMockId("tm"),
          ticketId: "",
          authorType: "AGENT",
          authorName: agent.name,
          body: String(body.description || body.subject),
          createdAt: (/* @__PURE__ */ new Date()).toISOString()
        }
      ]
    };
    tkt.messages[0].ticketId = tkt.id;
    db.tickets.unshift(tkt);
    return ok(tkt, `Field issue ${tkt.ticketNumber} escalated to MyNet NOC.`);
  }
  throw createError({
    statusCode: 404,
    statusMessage: `Unknown mock MyNet endpoint: ${method} ${path}`
  });
});

export { ____slug_ as default };
//# sourceMappingURL=_...slug_.mjs.map
