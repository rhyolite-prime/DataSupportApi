const interopDefault = r => r.default || r || [];
const styles = {
  "../../../node_modules/nuxt/dist/app/components/error-500.vue": () => import('../build/error-500-styles.C8oYM7BZ.mjs').then(interopDefault),
  "../../../node_modules/nuxt/dist/app/components/error-404.vue": () => import('../build/error-404-styles.7-OcUNOG.mjs').then(interopDefault)
};

const inlinedCSS = {"error-404.FPLB7Vob.css":[["../../../node_modules/nuxt/dist/app/components/error-404.vue"]],"error-500.B36KWJn0.css":[["../../../node_modules/nuxt/dist/app/components/error-500.vue"]]};

export { styles as default, inlinedCSS };
//# sourceMappingURL=styles.mjs.map
